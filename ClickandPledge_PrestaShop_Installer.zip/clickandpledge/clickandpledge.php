<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/


use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}
	// check if the order status is defined
		if (!defined('_PS_CNP_CREDITCARD_ORDER_STATUS_') || !defined('_PS_CNP_ECHECK_ORDER_STATUS_') || !defined('_PS_CNP_INVOICE_ORDER_STATUS_') || !defined('_PS_CNP_PURCHASE_ORDER_STATUS_') || !defined('_PS_CNP_CREDITCARD_RECURRING_ORDER_STATUS_') || !defined('_PS_CNP_ECHECK_RECURRING_ORDER_STATUS_')) {
				// order status is not defined - check if, it exists in the table
			$rq = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP Credit Card Payment"');
			
			if ($rq && isset($rq['id_order_state']) && intval($rq['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_CREDITCARD_ORDER_STATUS_', $rq['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_creditcard = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_creditcard) . ', 1, \'CnP Credit Card Payment\',\'payment\')');
				define('_PS_CNP_CREDITCARD_ORDER_STATUS_', $cnp_creditcard);

			   }

			$rq_check = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang` WHERE id_lang = 1 AND  name ="CnP eCheck Payment"');
			
			if ($rq_check && isset($rq_check['id_order_state']) && intval($rq_check['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_ECHECK_ORDER_STATUS_', $rq_check['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_echeck = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_echeck) . ', 1, \'CnP eCheck Payment\',\'payment\')');
				define('_PS_CNP_ECHECK_ORDER_STATUS_',$cnp_echeck);

			   }
			$rq_invoice = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP Awaiting Custom Payment"');
			
			if ($rq_invoice && isset($rq_invoice['id_order_state']) && intval($rq_invoice['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_INVOICE_ORDER_STATUS_', $rq_invoice['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'RoyalBlue\',1,1,\'clickandpledge\',1)');
				$cnp_invoice = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_invoice) . ', 1, \'CnP Awaiting Custom Payment\',\'cheque\')');
				define('_PS_CNP_INVOICE_ORDER_STATUS_', $cnp_invoice);

			   }
		
			   
			$rq_rp_credit = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP Credit Card Recurring Payment"');
			
			if ($rq_rp_credit && isset($rq_rp_credit['id_order_state']) && intval($rq_rp_credit['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_CREDITCARD_RECURRING_ORDER_STATUS_', $rq_rp_credit['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_creditcard_recurring = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_creditcard_recurring) . ', 1, \'CnP Credit Card Recurring Payment\',\'payment\')');
				define('_PS_CNP_CREDITCARD_RECURRING_ORDER_STATUS_', $cnp_creditcard_recurring);

			   }
			   
			$rq_rp_invoice = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP eCheck Recurring Payment"');
			
			if ($rq_rp_invoice && isset($rq_rp_invoice['id_order_state']) && intval($rq_rp_invoice['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_ECHECK_RECURRING_ORDER_STATUS_', $rq_rp_invoice['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_echeck_recurring = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_echeck_recurring) . ', 1, \'CnP eCheck Recurring Payment\',\'payment\')');
				define('_PS_CNP_ECHECK_RECURRING_ORDER_STATUS_', $cnp_echeck_recurring);

			   }
			}
class clickandpledge extends PaymentModule
{
    private $_html = '';
    private $_postErrors = array();

    public $accountid;
    public $guid;
    public $extra_mail_vars;
	public $module_dir ="clickandpledge";
    public function __construct()
    {
        $this->name = 'clickandpledge';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'Click & Pledge';
        $this->controllers = array('validation');

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $config = Configuration::getMultiple(array('CLICKANDPLEDGE_LOGIN_ID', 'CLICKANDPLEDGE_KEY'));
        if (isset($config['CLICKANDPLEDGE_LOGIN_ID'])) {
            $this->accountid = $config['CLICKANDPLEDGE_LOGIN_ID'];
        }
        if (isset($config['CLICKANDPLEDGE_KEY'])) {
            $this->guid = $config['CLICKANDPLEDGE_KEY'];
        }
		 if (isset($config['clickandpledge_campaign'])) {
            $this->campaign = $config['clickandpledge_campaign'];
        }
		 if (isset($config['clickandpledge_transactionmode'])) {
            $this->transactionmode = $config['clickandpledge_transactionmode'];
        }
		if (isset($config['clickandpledge_status'])) {
            $this->status = $config['clickandpledge_status'];
        }
		 if (isset($config['clickandpledge_org_info'])) {
            $this->org_info = $config['clickandpledge_org_info'];
        }
		 if (isset($config['clickandpledge_terms_condition'])) {
            $this->terms_condition = $config['clickandpledge_terms_condition'];
        }
		 if (isset($config['clickandpledge_send_receipt'])) {
            $this->send_receipt = $config['clickandpledge_send_receipt'];
        }
		 if (isset($config['options_clickandpledge_creditcard'])) {
            $this->creditcard = $config['options_clickandpledge_creditcard'];
        }
		 if (isset($config['options_clickandpledge_check'])) {
            $this->check = $config['options_clickandpledge_check'];
        }
		 if (isset($config['options_clickandpledge_custompayment'])) {
            $this->custompayment = $config['options_clickandpledge_custompayment'];
        }
		 if (isset($config['clickandpledge_title'])) {
            $this->title = $config['clickandpledge_title'];
        }
		 if (isset($config['clickandpledge_refnumlabel'])) {
            $this->refnumlabel = $config['clickandpledge_refnumlabel'];
        }
		 if (isset($config['clickandpledge_payment_method_default'])) {
            $this->payment_method_default = $config['clickandpledge_payment_method_default'];
        }
		 
		if (isset($config['clickandpledge_recurring_contribution_'])) {
            $this->recurring = $config['clickandpledge_recurring_contribution_'];
        }
		if (isset($config['prdcty_clickandpledge_week'])) {
            $this->week = $config['prdcty_clickandpledge_week'];
        }
		if (isset($config['prdcty_clickandpledge_2_weeks'])) {
            $this->tweeks = $config['prdcty_clickandpledge_2_weeks'];
        }
		if (isset($config['prdcty_clickandpledge_month'])) {
            $this->month = $config['prdcty_clickandpledge_month'];
        }
		if (isset($config['prdcty_clickandpledge_2_months'])) {
            $this->tmonths = $config['prdcty_clickandpledge_2_months'];
        }
		if (isset($config['prdcty_clickandpledge_quarter'])) {
            $this->quarter = $config['prdcty_clickandpledge_quarter'];
        }
		if (isset($config['prdcty_clickandpledge_6_months'])) {
            $this->smonths = $config['prdcty_clickandpledge_6_months'];
        }
		if (isset($config['prdcty_clickandpledge_year'])) {
            $this->year = $config['prdcty_clickandpledge_year'];
        }
		if (isset($config['rec_clickandpledge_installment'])) {
            $this->installment = $config['rec_clickandpledge_installment'];
        }
		if (isset($config['rec_clickandpledge_subscription'])) {
            $this->subscription = $config['rec_clickandpledge_subscription'];
        }
		if (isset($config['ind_clickandpledge_indefinite'])) {
            $this->indefinite = $config['ind_clickandpledge_indefinite'];
        }
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Click & Pledge');
        $this->description = $this->trans('This module allows you to accept payments by Click & Pledge.');
        $this->confirmUninstall = $this->trans('Are you sure you want to delete these details?');
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
		
		if (!is_callable('curl_exec')){
				$this->warning = $this->trans("cURL extension must be enabled on your server to use this module.");
		}
        if ((!isset($this->accountid) || !isset($this->guid) || empty($this->accountid) || empty($this->guid))) {
            $this->warning = $this->trans('The "Account ID" and "GUID" fields must be configured before using this module.');
        }
        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->trans('No currency has been set for this module.');
        }

        /*$this->extra_mail_vars = array(
                                    '{CLICKANDPLEDGE_LOGIN_ID}' => Configuration::get('CLICKANDPLEDGE_LOGIN_ID'),
                                    '{CLICKANDPLEDGE_KEY}' => Configuration::get('CLICKANDPLEDGE_KEY'))
                                );*/
    }

    public function install()
    {
	
		 if (!parent::install() || !$this->registerHook('paymentOptions') || !$this->registerHook('paymentReturn') 
		 ||  !$this->registerHook('actionAdminControllerSetMedia')) {
            return false;
        }
        return true;
        /* return parent::install()
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn')
			&& $this->registerHook('orderConfirmation') 
			&& $this->registerHook('payment')
			&& Configuration::updateValue('CLICKANDPLEDGE_DEMO', 1) 
			&& Configuration::updateValue('CLICKANDPLEDGE_SEND_RECEIPT_US', '1') 
			&& Configuration::updateValue('CLICKANDPLEDGE_CREDITCARD', 'Credit Card') 
			&& Configuration::updateValue('PAYMENT_METHOD_DEFAULT', 'Creditcard')
        ;*/
    }

    public function uninstall()
    {
        return Configuration::deleteByName('CLICKANDPLEDGE_LOGIN_ID')
            && Configuration::deleteByName('CLICKANDPLEDGE_KEY')
			&& Configuration::deleteByName('clickandpledge_campaign')
			&& Configuration::deleteByName('clickandpledge_transactionmode')
			&& Configuration::deleteByName('clickandpledge_status')
			&& Configuration::deleteByName('clickandpledge_org_info')
			&& Configuration::deleteByName('clickandpledge_terms_condition')
			&& Configuration::deleteByName('clickandpledge_send_receipt')
			&& Configuration::deleteByName('options_clickandpledge_creditcard')
			&& Configuration::deleteByName('options_clickandpledge_check')
			&& Configuration::deleteByName('options_clickandpledge_custompayment')
			&& Configuration::deleteByName('clickandpledge_title')
			&& Configuration::deleteByName('clickandpledge_refnumlabel')
			&& Configuration::deleteByName('clickandpledge_payment_method_default')
			&& Configuration::deleteByName('clickandpledge_recurring_contribution_')
			&& Configuration::deleteByName('prdcty_clickandpledge_week')
			&& Configuration::deleteByName('prdcty_clickandpledge_2_weeks')
			&& Configuration::deleteByName('prdcty_clickandpledge_month')
			&& Configuration::deleteByName('prdcty_clickandpledge_2_months')
			&& Configuration::deleteByName('prdcty_clickandpledge_quarter')
			&& Configuration::deleteByName('prdcty_clickandpledge_6_months')
			&& Configuration::deleteByName('prdcty_clickandpledge_year')
			&& Configuration::deleteByName('rec_clickandpledge_installment')
			&& Configuration::deleteByName('rec_clickandpledge_subscription')
			&& Configuration::deleteByName('ind_clickandpledge_indefinite')
		
            && parent::uninstall()
        ;
    }
	public function floor_dec($number,$precision,$separator)
		{
		$numberpart=explode($separator,$number);
		$ceil_number= array($numberpart[0],substr($numberpart[1],0,2));
		return implode($separator,$ceil_number);
		}
	public function hookActionAdminControllerSetMedia()
		{
			
				if (method_exists($this->context->controller, 'addJquery'))
					$this->context->controller->addJquery();
	
				$this->context->controller->addJs($this->_path.'views/js/'.$this->name.'.js');
				 $this->context->controller->addCSS($this->_path.'/views/css/custom.css');
			
		}
    private function _postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('CLICKANDPLEDGE_LOGIN_ID')) {
                $this->_postErrors[] = $this->trans('The "Account Id" field is required.');
            } elseif (!Tools::getValue('CLICKANDPLEDGE_KEY')) {
                $this->_postErrors[] = $this->trans('The "GUID" field is required.');
            }elseif (!Tools::getValue('clickandpledge_campaign')) {
                $this->_postErrors[] = $this->trans('The "Campaign" field is required.');
            }elseif (!Tools::getValue('clickandpledge_transactionmode')) {
                $this->_postErrors[] = $this->trans('The "Transaction Mode" field is required.');
            }elseif (!Tools::getValue('clickandpledge_status')) {
                $this->_postErrors[] = $this->trans('The "Status" field is required.');
            }elseif (!Tools::getValue('clickandpledge_org_info')) {
                $this->_postErrors[] = $this->trans('The "Status" field is required.');
            }elseif (!Tools::getValue('clickandpledge_terms_condition')) {
                $this->_postErrors[] = $this->trans('The "Status" field is required.');
            }elseif (!Tools::getValue('options_clickandpledge_creditcard') &&  
			         !Tools::getValue('options_clickandpledge_check') && 
					 !Tools::getValue('options_clickandpledge_custompayment')) {
                $this->_postErrors[] = $this->trans('The "Payment Methods" field is required.');
            }elseif (!Tools::getValue('clickandpledge_payment_method_default')) {
                $this->_postErrors[] = $this->trans('The "Default Payment Method" field is required.');
            }elseif (!Tools::getValue('clickandpledge_recurring_contribution_')) {
                $this->_postErrors[] = $this->trans('The " Recurring contributions" field is required.');
            }elseif (!Tools::getValue('prdcty_clickandpledge_week') &&  
			         !Tools::getValue('prdcty_clickandpledge_2_weeks') && 
					 !Tools::getValue('prdcty_clickandpledge_month')&& 
					 !Tools::getValue('prdcty_clickandpledge_2_months')&& 
					 !Tools::getValue('prdcty_clickandpledge_quarter')&& 
					 !Tools::getValue('prdcty_clickandpledge_6_months')&& 
					 !Tools::getValue('prdcty_clickandpledge_year')) {
                $this->_postErrors[] = $this->trans('The "Periodicity" field is required.');
            }elseif (!Tools::getValue('rec_clickandpledge_installment') &&  
			         !Tools::getValue('rec_clickandpledge_subscription')) {
                $this->_postErrors[] = $this->trans('The "Recurring Method" field is required.');
            }elseif (!Tools::getValue('ind_clickandpledge_indefinite')) {
                $this->_postErrors[] = $this->trans('The "Enable Indefinite Recurring" field is required.');
            }
			
        }
    }

    private function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('CLICKANDPLEDGE_LOGIN_ID', Tools::getValue('CLICKANDPLEDGE_LOGIN_ID'));
            Configuration::updateValue('CLICKANDPLEDGE_KEY', Tools::getValue('CLICKANDPLEDGE_KEY'));
			Configuration::updateValue('clickandpledge_campaign', Tools::getValue('clickandpledge_campaign'));
			Configuration::updateValue('clickandpledge_transactionmode', Tools::getValue('clickandpledge_transactionmode'));
			Configuration::updateValue('clickandpledge_status', Tools::getValue('clickandpledge_status'));
			Configuration::updateValue('clickandpledge_org_info', Tools::getValue('clickandpledge_org_info'));
			Configuration::updateValue('clickandpledge_terms_condition', Tools::getValue('clickandpledge_terms_condition'));
			Configuration::updateValue('clickandpledge_send_receipt', Tools::getValue('clickandpledge_send_receipt'));
			Configuration::updateValue('options_clickandpledge_creditcard', Tools::getValue('options_clickandpledge_creditcard'));
			Configuration::updateValue('options_clickandpledge_check', Tools::getValue('options_clickandpledge_check'));
			Configuration::updateValue('options_clickandpledge_custompayment', Tools::getValue('options_clickandpledge_custompayment'));
			Configuration::updateValue('clickandpledge_title', Tools::getValue('clickandpledge_title'));
			Configuration::updateValue('clickandpledge_refnumlabel', Tools::getValue('clickandpledge_refnumlabel'));
			Configuration::updateValue('clickandpledge_payment_method_default', Tools::getValue('clickandpledge_payment_method_default'));
			Configuration::updateValue('clickandpledge_recurring_contribution_', Tools::getValue('clickandpledge_recurring_contribution_'));
			Configuration::updateValue('prdcty_clickandpledge_week', Tools::getValue('prdcty_clickandpledge_week'));
			Configuration::updateValue('prdcty_clickandpledge_2_weeks', Tools::getValue('prdcty_clickandpledge_2_weeks'));
			Configuration::updateValue('prdcty_clickandpledge_month', Tools::getValue('prdcty_clickandpledge_month'));
			Configuration::updateValue('prdcty_clickandpledge_2_months', Tools::getValue('prdcty_clickandpledge_2_months'));
			Configuration::updateValue('prdcty_clickandpledge_quarter', Tools::getValue('prdcty_clickandpledge_quarter'));
			Configuration::updateValue('prdcty_clickandpledge_6_months', Tools::getValue('prdcty_clickandpledge_6_months'));
			Configuration::updateValue('prdcty_clickandpledge_year', Tools::getValue('prdcty_clickandpledge_year'));
			Configuration::updateValue('rec_clickandpledge_installment', Tools::getValue('rec_clickandpledge_installment'));
			Configuration::updateValue('rec_clickandpledge_subscription', Tools::getValue('rec_clickandpledge_subscription'));
			Configuration::updateValue('ind_clickandpledge_indefinite', Tools::getValue('ind_clickandpledge_indefinite'));
        }
        $this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Notifications.Success'));
    }

    private function _displayCheck()
    {
        return $this->display(__FILE__, './views/templates/hook/infos.tpl');
    }

    public function getContent()
    {
        $this->_html = '';
		//Tools::addJS('');
		
        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        }

        $this->_html .= $this->_displayCheck();
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    public function hookPaymentOptions($params)
    {
	
        if (!$this->active) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
		
		$payment_options = [
         
            $this->getclickandpledgePaymentOption($params),
       
        ];
        return $payment_options;
		
      
    }
	public function getclickandpledgePaymentOption($params)
    {
        $clicknpledgeOption = new PaymentOption();
        $clicknpledgeOption->setCallToActionText($this->l('Click & Pledge'))
                       ->setForm($this->generateclicknpledgeForm($params))
                       ->setAdditionalInformation($this->display(__FILE__, 'views/templates/front/clickandpledge_infos.tpl'));
                   
        return $clicknpledgeOption;
    }
    protected function generateclicknpledgeForm($params)
    { //echo "<pre>";//print_r($params);->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/logo.jpg'));

		
     global $cookie, $smarty;
		
		$currencies_module = $this->getCurrency((int)$params['cart']->id_currency);
		$currency = $this->checkCurrency($params['cart']);
		$iso_code_num = $currencies_module->iso_code; 
		
		if(Configuration::get('clickandpledge_status') && Configuration::get('CLICKANDPLEDGE_LOGIN_ID') != '' && Configuration::get('CLICKANDPLEDGE_KEY') != '')
		{ 
		    $displaystatus = true;
			$login_id =  Configuration::get('CLICKANDPLEDGE_LOGIN_ID');
			$login_key =  Configuration::get('CLICKANDPLEDGE_KEY');
			$app_campaign = Configuration::get('clickandpledge_campaign');
			$mode = Configuration::get('clickandpledge_transactionmode') == 1 ? 'Production' : 'Test';
			
		}
		else{
		    $displaystatus = false;
		}
			
			$org_info =  Configuration::get('clickandpledge_org_info');
			$terms_condition = Configuration::get('clickandpledge_terms_condition');
			$send_recepit = Configuration::get('clickandpledge_send_receipt') == 1 ? 'yes' : 'no';
			$defalut_payment = Configuration::get('clickandpledge_payment_method_default');
			$recurring = Configuration::get('clickandpledge_recurring_contribution_')== 'on' ? 'yes' : 'no';
			$week =  Configuration::get('prdcty_clickandpledge_week');
			$week2 =  Configuration::get('prdcty_clickandpledge_2_weeks');
			$month =  Configuration::get('prdcty_clickandpledge_month');
			$months2 =  Configuration::get('prdcty_clickandpledge_2_months');
			$quarter =  Configuration::get('prdcty_clickandpledge_quarter');
			$months6 =  Configuration::get('prdcty_clickandpledge_6_months');
			$year =  Configuration::get('prdcty_clickandpledge_year');
			$recurring_installment = Configuration::get('rec_clickandpledge_installment');
			$recurring_subscription = Configuration::get('rec_clickandpledge_subscription');
			$subscription_indefinite = Configuration::get('ind_clickandpledge_indefinite');
			
			$refnumlabel = Configuration::get('clickandpledge_refnumlabel');
			$titles      = Configuration::get('clickandpledge_title');
			
			
			$creditcard = $defalut_payment == 'Creditcard' ? 'Creditcard' : Configuration::get('options_clickandpledge_creditcard');
			$check = $defalut_payment == 'eCheck' ? 'eCheck' : Configuration::get('options_clickandpledge_check');
			$custompayment = $defalut_payment == 'custompayment' ? 'custompayment' : Configuration::get('options_clickandpledge_custompayment');
			if($creditcard == "on"){$creditcard ="Creditcard";}if($check == "on"){$check ="eCheck";}if($custompayment == "on"){$custompayment ="custompayment";}
			
			if($recurring_installment == "on"){$recurring_installment ="Installment";}
			if($recurring_subscription == "on"){$recurring_subscription ="Subscription";}
			if($subscription_indefinite == "on"){$subscription_indefinite ="indefinite";}
			
			if($recurring_installment == "on"){$recurring_installment ="Installment";}
			if($recurring_subscription == "on"){$recurring_subscription ="Subscription";}
			if($subscription_indefinite == "on"){$subscription_indefinite ="indefinite";}
			
			if($week == "on"){$week ="Week";}
			if($week2 == "on"){$week2 ="2 Weeks";}
			if($month == "on"){$month ="Month";}
			if($months2 == "on"){$months2 ="2 Months";}
			if($quarter == "on"){$quarter ="Quarter";}
			if($months6 == "on"){$months6 ="6 Months";}
			if($year == "on"){$year ="Year";}
			
			
			 //shipping address
		    $invoiceAddress = new Address((int)$params['cart']->id_address_delivery);
			
			//billing address
		    $billingAddress = new Address((int)$params['cart']->id_address_invoice);
			$customer = new Customer((int)$cookie->id_customer);
			$shipping_method = new Carrier((int)$params['cart']->id_carrier);
			$oldMessage = new Message();
			
			$getmesdetails =$oldMessage->getMessageByCartId((int)$params['cart']->id);
			//MessageCore::getMessageByCartId(intval($params['cart']->id));
			
			$shipping_method_name = $shipping_method->name;
			$Totaltax = (float)($params['cart']->getOrderTotal(true, Cart::BOTH) - $params['cart']->getOrderTotal(false, Cart::BOTH));
			$productamount = $params['cart']->getOrderTotal(false, Cart::BOTH);
		 	$finalamount = $params['cart']->getOrderTotal(true, Cart::BOTH);		
			
			$cnpParams = array();
			$cnpParams['x_login'] = $login_id;
			$cnpParams['x_tran_key'] = $login_key;
			$cnpParams['x_org_info'] = $org_info;
			$cnpParams['x_app_campaign'] = $app_campaign; 
			$cnpParams['x_send_recepit'] = $send_recepit;
			$cnpParams['x_terms_condition'] = $terms_condition;
			$cnpParams['x_thankyou_message'] = $thankyou_message;
			$cnpParams['x_titles'] = $titles;
			$cnpParams['x_referenceno'] = $refnumlabel;
			//$cnpParams['x_currency'] = $cookie->id_currency;
			$cnpParams['x_currency_code'] = $iso_code_num;
			
			$cnpParams['x_version'] = '2.0';
			$cnpParams['x_delim_data'] = 'TRUE';
			$cnpParams['x_delim_char'] = '|';
			$cnpParams['x_relay_response'] = 'FALSE';
			$cnpParams['x_type'] = 'AUTH_CAPTURE';
			//$cnpParams['x_method'] = 'CC';
			$cnpParams['x_test_request'] = $mode;
			$cnpParams['x_invoice_num'] = (int)$params['cart']->id;
			$cnpParams['x_amount'] = number_format($params['cart']->getOrderTotal(true, 3), 2, '.', '');
			$cnpParams['x_address1'] = $invoiceAddress->address1;
			$cnpParams['x_address2'] = $invoiceAddress->address2;
			$cnpParams['x_zip'] = $invoiceAddress->postcode;
			$cnpParams['customer_gender'] = $customer->id_gender;
			$cnpParams['x_first_name'] = $customer->firstname;
			$cnpParams['x_last_name'] = $customer->lastname;
			$cnpParams['x_email'] = $customer->email;
			$cnpParams['customer_birthday'] = $customer->birthday;
			$cnpParams['x_gift'] = $params['cart']->gift;
			$cnpParams['x_gift_message'] = "";	
			$cnpParams['x_comment_message'] = $getmesdetails['message'];				
			$cnpParams['x_phone'] = (!empty($invoiceAddress->phone_mobile)) ? $invoiceAddress->phone_mobile : $invoiceAddress->phone;
			$cnpParams['x_city'] = $invoiceAddress->city;
			$cnpParams['x_state'] = State::getNameById($invoiceAddress->id_state);
			$cnpParams['x_country'] = $invoiceAddress->id_country;
			$cnpParams['x_total_product'] = $params['cart']->nbProducts();
			
			if($cnpParams['x_state']==""){
			$cnpParams['x_state']="States Not Available";
			
			}
			if($cnpParams['x_gift']==1){			
				$cnpParams['x_gift_message'] = $params['cart']->gift_message;
			}else{
				$cnpParams['x_gift_message'] = "Not selected";
			}
			
			// billing information
			$cnpParams['x_b_address1'] = $billingAddress->address1;
			$cnpParams['x_b_address2'] = $billingAddress->address2;
			$cnpParams['x_b_zip'] = $billingAddress->postcode;
			$cnpParams['x_b_first_name'] = $billingAddress->firstname;
			$cnpParams['x_b_last_name'] = $billingAddress->lastname;
			$cnpParams['x_b_company'] = $billingAddress->company;
			$cnpParams['x_b_add_info'] = $billingAddress->other;
			$cnpParams['x_b_phone_home'] = $billingAddress->phone;
			$cnpParams['x_b_phone'] = (!empty($billingAddress->phone_mobile)) ? $billingAddress->phone_mobile : $billingAddress->phone;
			$cnpParams['x_b_city'] = $billingAddress->city;
			$cnpParams['x_b_state'] = State::getNameById($billingAddress->id_state);
			$cnpParams['x_b_country'] = $billingAddress->id_country;
			$cnpParams['x_shipping_method'] = $shipping_method_name;
			if($cnpParams['x_b_state']==""){
			$cnpParams['x_b_state']="States Not Available";
			
			}
			
			//shipping contact information
			$cnpParams['x_s_first_name'] = $invoiceAddress->firstname;
			$cnpParams['x_s_last_name'] = $invoiceAddress->lastname;
			$cnpParams['x_s_company'] = $invoiceAddress->company;
			$cnpParams['x_s_add_info'] = $invoiceAddress->other;
			$cnpParams['x_s_phone_home'] = $invoiceAddress->phone;
			$cnpParams['x_s_phone'] = (!empty($invoiceAddress->phone_mobile)) ? $invoiceAddress->phone_mobile : $invoiceAddress->phone;
			//echo "<pre>";
			//print_r($cnpParams);
			$val=$params['cart']->getProducts();
			$applyAllRules = new SpecificPrice();
			
		    $currency = Currency::getCurrency((int)$params['cart']->id_currency);
			$sign = $currency['sign'];
			
			$taxCalculationMethod = Group::getPriceDisplayMethod((int)$customer->id_default_group);
			$useTax = !($taxCalculationMethod == PS_TAX_EXC);
			
			$shipping=Tools::displayPrice($params['cart']->getOrderTotal($useTax, Cart::ONLY_SHIPPING), $currency);
			
			$cr=array($sign,",","-");
			 			
			//$shipping_cost=str_replace($cr,'',$shipping);
			if($taxCalculationMethod == PS_TAX_EXC)
			{
			$shipping_cost = $params['cart']->getOrderTotal($useTax, Cart::ONLY_SHIPPING);
			}
			else
			{
			 $shipping_cost = $params['cart']->getOrderTotal('', Cart::ONLY_SHIPPING);
			}
			$cnpParams['x_shipping_cost']=$shipping_cost;
			
			$discount = $params['cart']->getDiscounts();
			//echo "<pre>";
			//print_r($discount);
			$coupon_code = '';
			$coupon_discount = 000;
			if(!empty($discount))
			{
				// $coupon_code = $discount[0]['name'];
				for($i=0;$i < count($discount);$i++)
				{
				 $coupon_code .= $discount[$i]['code'].',';
				 
				 $coupon_discount = number_format(str_replace($cr,'',$discount[$i]['value_tax_exc']),'2','.','') + $coupon_discount;
				 }
			}
			//echo $coupon_discount;
			//			exit;

			$cnpParams['x_coupon_code'] = substr($coupon_code,0,-1);
			$cnpParams['x_coupon_discount'] = $coupon_discount;
			$cnpParams['x_total_tax'] = $Totaltax;
			$cnpParams['x_final_amount'] = $finalamount;
			
			for($i=0;$i<count($val);$i++)
			{
				$myprod = new Product($val[$i]['id_product']);
				$features = $myprod->getFrontFeatures($val[$i]['id_product']);
				
				//$getDefaultAttribute = $myprod->getDefaultAttribute(1);
				//print_r($getDefaultAttribute);exit;
				
				$getFeature = new Feature();
				$ff = $getFeature->getFeature(1,6);
				
				$pid = $val[$i]['id_product'];
				
				 if(count($features) > 0)
				 {
				 foreach($features as $new_few)
				 {
				 $fid =  $new_few['id_feature'];
			
				 
		$rq = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'feature_product` WHERE id_feature ='.$fid.' AND  id_product ='.$pid.'');
		if(count($rq) > 0)
		{
		$new_fid = $rq['id_feature'];
		$new_fid_val = $rq['id_feature_value'];
		$feacture_name = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'feature_lang` WHERE id_feature ='.$new_fid.' AND  name in("SKU","Campaign") and id_lang =1');
		if(count($feacture_name) > 0)
		{
		$feacture_value = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'feature_value_lang` WHERE id_feature_value ='.$new_fid_val.' and id_lang =1');
			if($feacture_name['name'] == 'SKU')
			{
			$cnpParams['x_product_sku['.$i.']'] = $feacture_value['value'];
			}
			if($feacture_name['name'] == 'Campaign')
			{
			$cnpParams['x_product_campaign['.$i.']'] = $feacture_value['value'];
			 }
		}	
		}
				
				}
				
				}
				//echo "<pre>";
			//	print_r($params['cart']);
				
				$nn = $applyAllRules->getSpecificPrice($val[$i]['id_product'],$params['cart']->id_shop,$cookie->id_currency,$cookie->id_country,0,1,null,0,0,1);
			//	print_r($nn);
				if(is_array($nn))
				{
					if($nn['reduction_type'] == 'percentage')
						{
				//$cnpParams['x_product_price['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2);
				$cnpParams['x_product_price_unitdiscount['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2) * $nn['reduction'];
						          
						//echo "wait".$cal_pro;
						}else{
				//$cnpParams['x_product_price['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2);
				$cnpParams['x_product_price_unitdiscount['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2) - $nn['reduction'];
						}
				}
		//	exit;
				 $cnpParams['x_product_price['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2);
			     $cnpParams['x_product_id['.$i.']'] = $val[$i]['id_product'];
				 $cnpParams['x_product_unique_id['.$i.']'] = $val[$i]['unique_id'];
			     $cnpParams['x_product_name['.$i.']'] = $val[$i]['name'];
				 $cnpParams['x_product_quantity['.$i.']'] = $val[$i]['cart_quantity'];
				// $cnpParams['x_product_price['.$i.']'] = $val[$i]['price'];
				 $cnpParams['x_product_tax['.$i.']'] = number_format($val[$i]['ecotax'],'2','.','');
				// echo $val[$i]['price_attribute'];exit;
				 $cnpParams['x_selected_attribute_price['.$i.']'] = $val[$i]['price_attribute'];
				// $cnpParams['x_product_price_unitdiscount['.$i.']'] = number_format((($myprod->price +  $cnpParams['x_selected_attribute_price['.$i.']']) - $cnpParams['x_product_price['.$i.']']),'2','.','');
				 $cnpParams['x_product_attributes_name['.$i.']'] = $val[$i]['attributes'];
				 
			}
			$isFailed = Tools::getValue('aimerror');

			$cards = array();
			$recurring_units = array();
			$recurring_method = array();
			if($creditcard != '')$cards['Creditcard'] = $creditcard;
			if($check != '')$cards['eCheck'] = $check;
			if($titles != '')
			{
			 $CustomPayments = explode(';', html_entity_decode($titles ));
				if(count($CustomPayments) > 0) {
					foreach($CustomPayments as $key => $val) {
						if(trim($val) != '') {
							$cards[trim($val)] = trim($val);
						
						}
					}
				}		
			}//$cards['custompayment'] = $custompayment;
		
			if($recurring == 'yes')
			{
			if($week != '')$recurring_units['Week'] = $week;
			if($week2 != '')$recurring_units['Weeks2'] = $week2;
			if($month != '')$recurring_units['Month'] = $month;
			if($months2 != '')$recurring_units['Months2'] = $months2;
			if($quarter != '')$recurring_units['Quarter'] = $quarter;
			if($months6 != '')$recurring_units['Months6'] = $months6;
			if($year != '')$recurring_units['Year'] = $year;
			
			if($recurring_installment != '')$recurring_method['installment'] = $recurring_installment;
			if($recurring_subscription != '')
				{
				
				$recurring_method['subscription'] = $recurring_subscription;
				if($subscription_indefinite != '') $indefinite = $subscription_indefinite;
				
				}
			}
		
			$this->context->smarty->assign('p', $cnpParams);			
			$this->context->smarty->assign('cards', $cards);
			$this->context->smarty->assign('recurring', $recurring);
			$this->context->smarty->assign('recurring_units', $recurring_units);
			$this->context->smarty->assign('recurring_method', $recurring_method);
			$this->context->smarty->assign('indefinite', $indefinite);
			$this->context->smarty->assign('isFailed', $isFailed);
			$this->context->smarty->assign('defalut_payment', $defalut_payment);
			$this->context->smarty->assign('refnumlabel', $refnumlabel);
			$this->context->smarty->assign('module_dir', $base_dir.'modules/clickandpledge/');
			//echo $refnumlabel ."----".$titles ;print_r($cards);
			
		 if($displaystatus)
			{
			   
			    return $this->context->smarty->fetch('module:clickandpledge/views/templates/front/clickandpledge_form.tpl');
			   //return $this->display(__FILE__, 'views/templates/front/clickandpledge_form.tpl');
			}

        
    }
    public function hookPaymentReturn($params)
    {
       
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency((int)($cart->id_currency));
        $currencies_module = $this->getCurrency((int)$cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function renderForm()
    {
				 $options = array(
				  array(
					'id_option' => "clickandpledge_creditcard",       
					'name' => 'Credit Card',   
					'values' => '1',
				  ),
				  array(
					'id_option' => "clickandpledge_check",
					'name' => 'eCheck'
				  ),
				   array(
					'id_option' => "clickandpledge_custompayment",
					'name' => 'Custom Payment'
				  ),
				);
				 $recoptions = array(
				  array(
					'id_option' => 1,       
					'name' => '(Supported for Credit card and eCheck)'    
				  ),
				
				);
				$prdctyoptions = array(
				  array(
					'id_option1' => "clickandpledge_week",      
					'name' => 'Week'    
				  ),
				  array(
					'id_option1' => "clickandpledge_2_weeks",
					'name' => '2 Weeks'
				  ),
				   array(
					'id_option1' => "clickandpledge_month",
					'name' => 'Month'
				  ),
				  array(
					'id_option1' => "clickandpledge_2_months",      
					'name' => '2 Months'    
				  ),
				  array(
					'id_option1' => "clickandpledge_quarter",
					'name' => 'Quarter'
				  ),
				   array(
					'id_option1' => "clickandpledge_6_months",
					'name' => '6 Months'
				  ),
					   array(
					'id_option1' => "clickandpledge_year",
					'name' => 'Year'
				  ),
			
				);
			 $rectypptions = array(
			  array(
				'id_option3' => "clickandpledge_installment",      
				'name' => 'Installment (example: Split $1000 into 10 payments of $100 each)'   
			  ),
			 array(
				'id_option3' => "clickandpledge_subscription",      
				'name' => 'Subscription (example: Pay $10 every month for 20 times)'    
			  ),
			
			);
			$indrecoptions = array(
			  array(
				'id_option4' => "clickandpledge_indefinite",      
				'name' => ' Indefinite (~) optional'    
			  ),
			
			);
	
			$fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans('Settings'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Account Id'),
                        'name' => 'CLICKANDPLEDGE_LOGIN_ID',
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('GUID'),
                        'name' => 'CLICKANDPLEDGE_KEY',
                        'required' => true
                    ),
					  array(
                        'type' => 'text',
                        'label' => $this->trans('Campaign'),
                        'name' => 'clickandpledge_campaign',
                        'required' => true
                    ),
					 array(
                        'type' => 'radio',
                        'label' => $this->l('Transaction mode'),
                        'name' => 'clickandpledge_transactionmode',
                        'values' => array(
                            array(
                                'id' => 'clickandpledge_transactionmode',
                                'value' => '1',
								'checked' => 'checked',
                                'label' => $this->l('Production')
                            ),
                            array(
                                'id' => 'clickandpledge_transactionmode',
                                'value' => '0',
								
                                'label' => $this->l('Test')
                            )
                        )
                    ),
					 array(
                        'type' => 'radio',
                        'label' => $this->l('Status'),
                        'name' => 'clickandpledge_status',
                        'values' => array(
                            array(
                                'id' => 'clickandpledge_status',
                                'value' => '1',
                                'label' => $this->l('Enable')
                            ),
                            array(
                                'id' => 'clickandpledge_status',
                                'value' => '0',
                                'label' => $this->l('Disable')
                            )
                        )
						
                    ),
					 array(
                        'type' => 'textarea',
                        'label' => $this->trans('Organization Information'),
                        'name' => 'clickandpledge_org_info',
                        'required' => true
                    ),  array(
                        'type' => 'textarea',
                        'label' => $this->trans('Terms & Condition'),
                        'name' => 'clickandpledge_terms_condition',
                        'required' => true
                    ),
					 array(
                        'type' => 'switch',
                        'label' => $this->trans('Send Receipt to Patron'),
                        'name' => 'clickandpledge_send_receipt',
                        'required' => true,
						'values' => array(
                            array(
                                'id' => 'clickandpledge_send_receipt',
                                'value' => '1',
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'id' => 'clickandpledge_send_receipt',
                                'value' => '0',
                                'label' => $this->l('No')
                            )
                        )
                    ),
					array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Payment Methods'),         
						  'desc'    => $this->l('Choose Payment Methods.'), 
						  'name'    => 'options',  
						  'required' => true,                  
						  'values'  => array(
							'query' => $options,                     
							'id'    => 'id_option',                 
							'name'  => 'name')
                ),
				 array(
                        'type' => 'textarea',
                        'label' => $this->trans('Title(s)'),
                        'name' => 'clickandpledge_title',
                        'required' => true
                    ),  array(
                        'type' => 'text',
                        'label' => $this->trans('Reference Number Label'),
                        'name' => 'clickandpledge_refnumlabel',
                        'required' => true
                    ),
				  array(
                        'col' => 3,
                        'type' => 'select',
                        'prefix' => '<i class="icon icon-tag"></i>',
                        'name' => 'clickandpledge_payment_method_default',
                        'label' => $this->l('Default Payment Method'),
						'required' => true, 
                        'options' => array(
                            'query' => array(
                               
                                array(
                                    'id_lpa_prov' => 'Creditcard',
                                    'name' => $this->l('Credit Card')
                                ),
                                array(
                                    'id_lpa_prov' => 'eCheck',
                                    'name' => $this->l('eCheck')
                                ),
                                array(
                                    'id_lpa_prov' => 'custompayment',
                                    'name' => $this->l('Custom Payment')
                                )
                            ),
                            'id' => 'id_lpa_prov',
                            'name' => 'name'
                        )
                    ),
					array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Recurring contributions'),         
						  'name'    => 'clickandpledge_recurring_contribution',  
						  'required' => true, 
						  'class'    => "rectyp",                  
						  'values'   => array( 
							'query' => $recoptions,                     
							'id'    => 'id_option1',                 
							'name'  => 'name')
              		  	),
						array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Periodicity'),         
						  'name'    => 'prdcty',
						  'class'    => "clsprdcty",  
						  'required' => true,                  
						  'values'  => array( 
							'query' => $prdctyoptions,                     
							'id'    => 'id_option1',                 
							'name'  => 'name')
              		  	),
						array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Recurring Method'),         
						  'name'    => 'rec',
						  'class'    => "clsrecmthd",  
						  'required' => true,                  
						  'values'  => array( 
							'query' => $rectypptions,                     
							'id'    => 'id_option3',                 
							'name'  => 'name')
              		  	),
						array(
						  'type'     => 'checkbox',                   
						  'label'    => $this->l('Enable Indefinite Recurring'),         
						  'name'     => 'ind', 
						  'class'    => "clsindfnt",  
						  'required' => true,                  
						  'values'   => array( 
							'query' => $indrecoptions,                     
							'id'    => 'id_option4',                 
							'name'  => 'name')
              		  	),
                ),
                'submit' => array(
                    'title' => $this->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
        );

        $this->fields_form = array();

        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'CLICKANDPLEDGE_LOGIN_ID' => Tools::getValue('CLICKANDPLEDGE_LOGIN_ID', Configuration::get('CLICKANDPLEDGE_LOGIN_ID')),
            'CLICKANDPLEDGE_KEY' => Tools::getValue('CLICKANDPLEDGE_KEY', Configuration::get('CLICKANDPLEDGE_KEY')),
			'clickandpledge_campaign' => Tools::getValue('clickandpledge_campaign', Configuration::get('clickandpledge_campaign')),
			'clickandpledge_transactionmode' => Tools::getValue('clickandpledge_transactionmode', Configuration::get('clickandpledge_transactionmode')),
			'clickandpledge_status' => Tools::getValue('clickandpledge_status', Configuration::get('clickandpledge_status')),
			'clickandpledge_org_info' => Tools::getValue('clickandpledge_org_info', Configuration::get('clickandpledge_org_info')),
			'clickandpledge_terms_condition' => Tools::getValue('clickandpledge_terms_condition', Configuration::get('clickandpledge_terms_condition')),
			'clickandpledge_send_receipt' => Tools::getValue('clickandpledge_send_receipt', Configuration::get('clickandpledge_send_receipt')),
			'options_clickandpledge_creditcard' => Tools::getValue('options_clickandpledge_creditcard', Configuration::get('options_clickandpledge_creditcard')),
			'options_clickandpledge_check' => Tools::getValue('options_clickandpledge_check', Configuration::get('options_clickandpledge_check')),
			'options_clickandpledge_custompayment' => Tools::getValue('options_clickandpledge_custompayment', Configuration::get('options_clickandpledge_custompayment')),
			'clickandpledge_title' => Tools::getValue('clickandpledge_title', Configuration::get('clickandpledge_title')),
			'clickandpledge_refnumlabel' => Tools::getValue('clickandpledge_refnumlabel', Configuration::get('clickandpledge_refnumlabel')),
			'clickandpledge_payment_method_default' => Tools::getValue('clickandpledge_payment_method_default', Configuration::get('clickandpledge_payment_method_default')),
			'clickandpledge_recurring_contribution_' => Tools::getValue('clickandpledge_recurring_contribution_', Configuration::get('clickandpledge_recurring_contribution_')),
			'prdcty_clickandpledge_week' => Tools::getValue('prdcty_clickandpledge_week', Configuration::get('prdcty_clickandpledge_week')),
			'prdcty_clickandpledge_2_weeks' => Tools::getValue('prdcty_clickandpledge_2_weeks', Configuration::get('prdcty_clickandpledge_2_weeks')),
			'prdcty_clickandpledge_month' => Tools::getValue('prdcty_clickandpledge_month', Configuration::get('prdcty_clickandpledge_month')),
			'prdcty_clickandpledge_2_months' => Tools::getValue('prdcty_clickandpledge_2_months', Configuration::get('prdcty_clickandpledge_2_months')),
			'prdcty_clickandpledge_quarter' => Tools::getValue('prdcty_clickandpledge_quarter', Configuration::get('prdcty_clickandpledge_quarter')),
			'prdcty_clickandpledge_6_months' => Tools::getValue('prdcty_clickandpledge_6_months', Configuration::get('prdcty_clickandpledge_6_months')),
			'prdcty_clickandpledge_year' => Tools::getValue('prdcty_clickandpledge_year', Configuration::get('prdcty_clickandpledge_year')),
			'rec_clickandpledge_installment' => Tools::getValue('rec_clickandpledge_installment', Configuration::get('rec_clickandpledge_installment')),
			'rec_clickandpledge_subscription' => Tools::getValue('rec_clickandpledge_subscription', Configuration::get('rec_clickandpledge_subscription')),
			'ind_clickandpledge_indefinite' => Tools::getValue('ind_clickandpledge_indefinite', Configuration::get('ind_clickandpledge_indefinite')),

        );
    }

    
}