$(document).ready(function() { 
$('#clickandpledge_login_id').change(function() {
 if ($(this).is(':clickandpledge_login_id')) {
  
$(this).nextAll(':lt(2)').hide();

 } else {
  
$(this).nextAll(':lt(2)').show();
 }
});
});