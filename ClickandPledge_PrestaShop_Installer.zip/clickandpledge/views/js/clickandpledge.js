$(document).ready(function(){
	
	if(jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
	}
	else
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		 if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false){
		   jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		 }
		 else{ jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
		 }
	}
	/**/
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == false && jQuery("#options_clickandpledge_check").is(':checked') == false && 
			jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
		
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').hide();
	}
	else if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true && 
			jQuery("#options_clickandpledge_check").is(':checked') == true && 
			jQuery("#clickandpledge_recurring_contribution_").is(':checked') == true )
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').show();
		 if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false){
		   jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		 }
		 else{ jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
		 }
		
	}
	/**/
	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == false)
	{
		jQuery('#clickandpledge_title').parent().parent('div').hide();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').hide();
		
	}
	else
	{
		jQuery('#clickandpledge_title').parent().parent('div').show();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').show();
		
	}
	/**/
	/*if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false && jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
	jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();	
	}
	else if(jQuery("#rec_clickandpledge_subscription").is(':checked') == true && 
			jQuery("#clickandpledge_recurring_contribution_").is(':checked') == true && )
	{
	 jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();	
	}*/
	
	/**/
	jQuery('#clickandpledge_payment_method_default').html('');
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true)
	{
		if(jQuery("#clickandpledge_hdndfltpaymnt").val() == 'Creditcard')	defval_selected = "  selected";
	    else											                    defval_selected = "";
		jQuery('<option '+defval_selected+'>').val('Creditcard').text('Credit Card').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='Creditcard']").remove();
	}
	if(jQuery("#options_clickandpledge_check").is(':checked') == true)
	{
		if(jQuery("#clickandpledge_hdndfltpaymnt").val() == 'eCheck')	defval_selected = "  selected";
	    else											                    defval_selected = "";
		jQuery('<option '+defval_selected+'>').val('eCheck').text('eCheck').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='eCheck']").remove();
	}
	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == true)
	{ 
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				if(jQuery("#clickandpledge_hdndfltpaymnt").val() == splt[i])	defval_selected = "  selected";
				else											defval_selected = "";
				jQuery('<option '+defval_selected+'>').val(splt[i]).text(splt[i]).appendTo('#clickandpledge_payment_method_default');
				}
			}
		}
	}
 $("#clickandpledge_recurring_contribution_").click(function(){
 		if(jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
	}
	else
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
	}
			
 });
 $("#rec_clickandpledge_subscription").click(function(){
	if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false)
	{
	jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();	
	}
	else
	{
	jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();	
	}
 });
 
   $("#options_clickandpledge_custompayment").click(function(){
 	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == false)
	{
		jQuery('#clickandpledge_title').parent().parent('div').hide();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').hide();
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				$("#clickandpledge_payment_method_default option[value='"+splt[i]+"']").remove();
				
				}
			}
		}
		
	}
	else
	{
		jQuery('#clickandpledge_title').parent().parent('div').show();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').show();
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				if(jQuery("#clickandpledge_hdndfltpaymnt").val() == splt[i])	defval_selected = "  selected";
				else											                defval_selected = "";
				jQuery('<option '+defval_selected+'>').val(splt[i]).text(splt[i]).appendTo('#clickandpledge_payment_method_default');
				}
			}
		}
		
	}
			
 });         
 $("#options_clickandpledge_creditcard").click(function(){
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true)
	{
		jQuery('<option >').val('Creditcard').text('Credit Card').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='Creditcard']").remove();
	}
	chkrecSec();
   });   
  $("#options_clickandpledge_check").click(function(){
	if(jQuery("#options_clickandpledge_check").is(':checked') == true)
	{
		jQuery('<option >').val('eCheck').text('eCheck').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='eCheck']").remove();
	}
	chkrecSec();
   }); 
 
   $("#clickandpledge_title").change(function(){
	jQuery('#clickandpledge_payment_method_default').html('');
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true)
	{
			jQuery('<option >').val('Creditcard').text('Credit Card').appendTo('#clickandpledge_payment_method_default');
	}
	if(jQuery("#options_clickandpledge_check").is(':checked') == true)
	{
		jQuery('<option >').val('eCheck').text('eCheck').appendTo('#clickandpledge_payment_method_default');
	}
	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == true)
	{
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				if(jQuery("#clickandpledge_hdndfltpaymnt").val() == splt[i])	defval_selected = "  selected";
				else											                defval_selected = "";
				jQuery('<option '+defval_selected+'>').val(splt[i]).text(splt[i]).appendTo('#clickandpledge_payment_method_default');
				}
			}
		}
	}
	
   });  
   
   function chkrecSec()
   {
	   if(jQuery("#options_clickandpledge_creditcard").is(':checked') == false && jQuery("#options_clickandpledge_check").is(':checked') == false)
	{
		
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').hide();
	}
	else
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').show();
		 if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false){
		   jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		 }
		 else{ jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
		 }
		
	}
   }
});
