<?php 
require_once(dirname(__FILE__).'../../../config/config.inc.php');
require_once(dirname(__FILE__).'../../../init.php');

switch (Tools::getValue('method')) {
  case 'cnpGetCodeMethod' :
		$curl = curl_init();
		$cnpemailaddress = $_REQUEST['cnpemailid'];
		curl_setopt_array($curl, array(
  		CURLOPT_URL => "https://api.cloud.clickandpledge.com/users/requestcode",
  		CURLOPT_RETURNTRANSFER => true,
  	    CURLOPT_ENCODING => "",
  		CURLOPT_MAXREDIRS => 10,
  	    CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache",
        "content-type: application/x-www-form-urlencoded",
        "email: ".$cnpemailaddress
	  ),
	));

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo  $response;
}
    break;
  case 'cnpGetAccountsMethod' :
		$cnpemailid = $_REQUEST['cnpemailid'];
		$cnpcode    = $_REQUEST['cnpcode'];
		$cnptransactios = get_cnppstransactions($cnpemailid,$cnpcode);
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://aaas.cloud.clickandpledge.com/idserver/connect/token",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => $cnptransactios,
		CURLOPT_HTTPHEADER => array(
			"cache-control: no-cache",
			"content-type: application/x-www-form-urlencoded"

		  ),
		));

		$response = curl_exec($curl);
		$err      = curl_error($curl);
		curl_close($curl);
		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		$cnptokendata = json_decode($response);
		
		 if(!isset($cnptokendata->error)){
			$cnptoken = $cnptokendata->access_token;
			$cnprtoken = $cnptokendata->refresh_token;
			$cnptransactios = delete_cnppstransactions();
			$rtncnpdata =	insrt_cnppstokeninfo($cnpemailid,$cnpcode,$cnptoken,$cnprtoken);	
			
			if($rtncnpdata != "")
			{
				$curl = curl_init();

			  curl_setopt_array($curl, array(
  			  CURLOPT_URL => "https://api.cloud.clickandpledge.com/users/accountlist",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			  CURLOPT_HTTPHEADER => array(
				"accept: application/json",
				"authorization: Bearer ".$cnptoken,
				"content-type: application/json"),
			  	));

				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				 
					$cnpAccountsdata = json_decode($response);
				
					$cnptransactios = delete_pscnpaccountslist();
					
					foreach($cnpAccountsdata as $cnpkey =>$cnpvalue)
					{
					 $cnporgid = $cnpvalue->OrganizationId;
					 $cnporgname = addslashes($cnpvalue->OrganizationName);
					 $cnpaccountid = $cnpvalue->AccountGUID;
					 $cnpufname = addslashes($cnpvalue->UserFirstName);
					 $cnplname = addslashes($cnpvalue->UserLastName);
				     $cnpuid = $cnpvalue->UserId;
					 $cnptransactios = insert_cnppsaccountsinfo($cnporgid,$cnporgname,$cnpaccountid,$cnpufname,$cnplname,$cnpuid);	
						
					}
					
				   echo "success";
				}
			}
			}else{
				echo "error";
			 
			}
			
	    }
    break;
 case 'cnpUserAccountListMethod' :
		$cnppsaccountid = $_REQUEST['cnppsaccountid'];
		$cnprtrntxt = getpsCnPConnectCampaigns($cnppsaccountid);
        $cnprtrnpaymentstxt = getpsCnPactivePaymentList($cnppsaccountid);
		echo $cnprtrntxt."||".$cnprtrnpaymentstxt;
	     break;
  default:
    exit;
}

 function getpsCnPactivePaymentList($cnpaccid)
	{

		global $wpdb;
		$cmpacntacptdcards = "";
		$cnpacountid = $cnpaccid;
		$cnpaccountGUID = getpsCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect1  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client1   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect1);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr1  = new SimpleXMLElement("<GetAccountDetail></GetAccountDetail>");
			$xmlr1->addChild('accountId',$cnpacountid);
			$xmlr1->addChild('accountGUID',$cnpaccountGUID);
			$xmlr1->addChild('username',$cnpUID);
			$xmlr1->addChild('password',$cnpKey);
			$response1                    =  $client1->GetAccountDetail($xmlr1);
			$responsearramex              =  $response1->GetAccountDetailResult->Amex;
			$responsearrJcb               =  $response1->GetAccountDetailResult->Jcb;
			$responsearrMaster            =  $response1->GetAccountDetailResult->Master;
			$responsearrVisa              =  $response1->GetAccountDetailResult->Visa;
			$responsearrDiscover          =  $response1->GetAccountDetailResult->Discover;
			$responsearrecheck            =  $response1->GetAccountDetailResult->Ach;
			$responsearrCustomPaymentType =  $response1->GetAccountDetailResult->CustomPaymentType;
			
			/*$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_CreditCard" id="woocommerce_clickandpledge_CreditCard"';
			if($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true ){ 
				$cmpacntacptdcards .= ' value="CreditCard">';
			}else{ $cmpacntacptdcards .= ' value="">'; }
				$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_eCheck" id="woocommerce_clickandpledge_eCheck"';
			if($responsearrecheck == true){
				$cmpacntacptdcards .= ' value="eCheck">';
			}else{ $cmpacntacptdcards .= ' value="">'; }
			if($responsearramex == true){
			$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_American_Express" id="woocommerce_clickandpledge_American_Express" value="amex">';
			}
			if($responsearrJcb == true){
			$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_JCB" id="woocommerce_clickandpledge_JCB" value="jcb">';
			}
			if($responsearrMaster == true){
			$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_MasterCard" id="woocommerce_clickandpledge_MasterCard" value="Master">';
			}
			if($responsearrVisa == true){
			$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_Visa" id="woocommerce_clickandpledge_Visa" value="Visa">';
			}
			if($responsearrDiscover == true){
			$cmpacntacptdcards .= '<input type="hidden" name="woocommerce_clickandpledge_Discover" id="woocommerce_clickandpledge_Discover" value="Discover">';
			}
			$cmpacntacptdcards .= '<table cellpadding="5" cellspacing="3" style="font-weight:bold;padding:2px;" id="tblacceptedcards">
                    <tbody><tr>
                    <td width="200"><input type="checkbox" id="options_clickandpledge_creditcard" class="checkbox_active" value="CreditCard" name="options_clickandpledge_creditcard"';*/
			
			if(($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true) )
			{
				//$cmpacntacptdcards .= 'checked="checked"';}
			$cmpacntacptdcards .='<label for="options_clickandpledge_creditcard"><input type="checkbox" name="options_clickandpledge_creditcard" id="options_clickandpledge_creditcard" class="clspaymntmthd" checked="checked" disabled="disabled">Credit Card ('; 
		    /* $cmpacntacptdcards .= 'checked="checked" disabled="disabled"> Credit Card</td></tr>
			 <tr class="tracceptedcards"><td></td><td>
			 <table cellspacing="0">
					
					<tbody class="accounts">
						<tr class="account">								
									<td style="padding:2px;"><strong>Accepted Credit Cards</strong></td></tr>';*/
				$cmpacntacptdcards .= '<script>jQuery("#clickandpledge_Visa").val("");
				jQuery("#clickandpledge_Amex").val("");
				jQuery("#clickandpledge_Discover").val("");
				jQuery("#clickandpledge_MasterCard").val("");
				jQuery("#clickandpledge_JCB").val("");
				jQuery("#clickandpledge_hdnecheck").val("");</script>';
								if($responsearrVisa == true){
								$cmpacntacptdcards .= '<script>jQuery("#clickandpledge_Visa").val("visa");</script>';
									 $cmpacntacptdcards .= 'Visa';
								  }
								if($responsearramex == true){
									
									$cmpacntacptdcards .= '<script>jQuery("#clickandpledge_Amex").val("amex");</script>';
									$cmpacntacptdcards .= ', Amex';
								}if($responsearrDiscover == true){
								 
									$cmpacntacptdcards .= '<script>jQuery("#clickandpledge_Discover").val("discover");</script>';
										$cmpacntacptdcards .= ', Discover';
								}if($responsearrMaster == true){
								  $cmpacntacptdcards .= '<script>jQuery("#clickandpledge_MasterCard").val("master");</script>';
									$cmpacntacptdcards .=', MasterCard';
								}if($responsearrJcb == true){
								  
									$cmpacntacptdcards .= '<script>jQuery("#clickandpledge_JCB").val("jcb");</script>';
									$cmpacntacptdcards .= ', JCB	';
								}		//$cmpacntacptdcards .= '</tbody></table></td></tr>';
			$cmpacntacptdcards .=')</label></div>';	}
			if($responsearrecheck == true){
			$cmpacntacptdcards .='<div><label for="option_clickandpledge_check"><input type="checkbox" value="eCheck" id="options_clickandpledge_check" class="checkbox_active" name="options_clickandpledge_check" ';
				
				 $cmpacntacptdcards .= ' checked="checked" disabled="disabled"> eCheck</label></div>';
				$cmpacntacptdcards .= '<script>jQuery("#clickandpledge_hdnecheck").val("on");</script>';
			}else
			{
				$cmpacntacptdcards .= '
				<script>jQuery("#options_clickandpledge_check").val("");</script>';
				
			}
			if($responsearrCustomPaymentType == true){
				$cmpacntacptdcards .='<div><label for="option_clickandpledge_custompayment"><input type="checkbox" value="CustomPayment" id="options_clickandpledge_custompayment" class="checkbox_active" name="options_clickandpledge_custompayment"';
					 $cmpacntacptdcards .='checked="checked"';
				 $cmpacntacptdcards .= '> Custom Payment</label></div>';
			}
					$cmpacntacptdcards .= '<script>jQuery("#options_clickandpledge_custompayment").click(function() {
					if(jQuery("#options_clickandpledge_custompayment").is(":checked") == false)
					{var CustomPaymentTitles = jQuery("#clickandpledge_title").val();
						var splt = "";
						if(CustomPaymentTitles != "")
						{
							splt = CustomPaymentTitles.split(";");
							for(var i=0;i < splt.length; i++)
							{
								var spltVal = splt[i].trim();
								if( spltVal !="" ){ 
								
							jQuery("#clickandpledge_payment_method_default option[value=\'"+spltVal+"\']").remove();
								}
							}
						}
						jQuery("#clickandpledge_title").parent().parent("div").hide();
						jQuery("#clickandpledge_refnumlabel").parent().parent("div").hide();
						
						
					}
					else
					{ 
						
						var CustomPaymentTitles = jQuery("#clickandpledge_title").val();
						var splt = "";
						if(CustomPaymentTitles != "")
						{ 
							splt = CustomPaymentTitles.split(";");
							for(var i=0;i < splt.length; i++)
							{
								var spltVal = splt[i].trim();
								if( spltVal !="" ){ 
							
jQuery("#clickandpledge_payment_method_default").append("<option value="+spltVal+">"+spltVal+"</option>");
								}
							}
						}
						jQuery("#clickandpledge_title").parent().parent("div").show();
						jQuery("#clickandpledge_refnumlabel").parent().parent("div").show();
						

					}
				
			});</script>';

		}	
		
		return $cmpacntacptdcards;
	
	}
function getpsCnPAccountGUID($accid)
		{
		
			$cnpAccountGUId ="";
			$cnppssql = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'cnp_pscnpaccountsinfo` where cnpaccountsinfo_orgid ="'.$accid.'"');
			$cnpAccountGUId      = $cnppssql['cnpaccountsinfo_accountguid'];
			return $cnpAccountGUId;
		
		}
 function getpsCnPConnectCampaigns($cnpaccid)
	{

		$cnpacountid = $cnpaccid;
	    $cnpaccountGUID = getpsCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr  = new SimpleXMLElement("<GetActiveCampaignList2></GetActiveCampaignList2>");
			$cnpsel ="";
			$xmlr->addChild('accountId', $cnpacountid);
			$xmlr->addChild('AccountGUID', $cnpaccountGUID);
			$xmlr->addChild('username', $cnpUID);
			$xmlr->addChild('password', $cnpKey);
			$response = $client->GetActiveCampaignList2($xmlr); 
			$responsearr =  $response->GetActiveCampaignList2Result->connectCampaign;
			
			//need to get the active campaign
	
			 $camrtrnval = "<option value=''>Select Campaign Name</option>";
			 if(count($responsearr) == 1)
				{
					if($responsearr->alias == $cnpcampaignalias){ $cnpsel ="selected='selected'";}
				 $camrtrnval.= "<option value='".$responsearr->alias."' ".$cnpsel." >".$responsearr->name." (".$responsearr->alias.")</option>";
				}else{
					for($inc = 0 ; $inc < count($responsearr);$inc++)
					{ if($responsearr[$inc]->alias == $cnpcampaignalias){ $cnpsel ="selected='selected'";}else{$cnpsel ="";}
					 $camrtrnval .= "<option value='".$responsearr[$inc]->alias."' ".$cnpsel.">".$responsearr[$inc]->name." (".$responsearr[$inc]->alias.")</option>";
					}

				}	
				}
		
		return $camrtrnval;
			
		}
function get_cnppstransactions($cnpemailid,$cnpcode)
{
	$rtncnpdata ="";
	$cnppssql = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'cnp_pscnpsettingsinfo`');
	 $password="password";
	if($cnppssql['cnpsettingsinfo_clentsecret'] !=""){
			 $cnpsecret = openssl_decrypt($cnppssql['cnpsettingsinfo_clentsecret'],"AES-128-ECB",$password);
			 $rtncnpdata = "client_id=".$cnppssql['cnpsettingsinfo_clientid']."&client_secret=". $cnpsecret."&grant_type=".$cnppssql['cnpsettingsinfo_granttype']."&scope=".$cnppssql['cnpsettingsinfo_scope']."&username=".$cnpemailid."&password=".$cnpcode;
	}
	return $rtncnpdata;
	
}
function delete_cnppstransactions()
{
	$cnppsdelsql = Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'cnp_pscnptokeninfo`');
}
function delete_pscnpaccountslist()
{
	$cnppsdelsql = Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'cnp_pscnpaccountsinfo`');
  
}
function  insrt_cnppstokeninfo($cnpemailid, $cnpcode, $cnptoken, $cnprtoken)
{
	
		Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'cnp_pscnptokeninfo` (`cnptokeninfo_username`, `cnptokeninfo_code`,`cnptokeninfo_accesstoken`, `cnptokeninfo_refreshtoken`)
				VALUES("' . $cnpemailid . '","'.$cnpcode.'", "'.$cnptoken.'","'.$cnprtoken.'")');
            $id = Db::getInstance()->Insert_ID();
			
        return $id;
}
function insert_cnppsaccountsinfo($cnporgid,$cnporgname,$cnpaccountid,$cnpufname,$cnplname,$cnpuid){
  		
	Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'cnp_pscnpaccountsinfo` (`cnpaccountsinfo_orgid`, `cnpaccountsinfo_orgname`,`cnpaccountsinfo_accountguid`, `cnpaccountsinfo_userfirstname`,`cnpaccountsinfo_userlastname`,`cnpaccountsinfo_userid`)
				VALUES("' . $cnporgid . '","'.$cnporgname.'", "'.$cnpaccountid.'","'.$cnpufname.'","'.$cnplname.'","'.$cnpuid.'")');
            $id = Db::getInstance()->Insert_ID();
        return $id;
    }
?>