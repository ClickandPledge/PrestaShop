<?php
require_once(MODULE_DIR.'clickandpledge/clickandpledge.php');
if(Tools::getValue('token') != "")
{$mymenu = Module::getInstanceByName('clickandpledge');
$menu = $mymenu->cnphookFooter();
die($menu);
}
?>
