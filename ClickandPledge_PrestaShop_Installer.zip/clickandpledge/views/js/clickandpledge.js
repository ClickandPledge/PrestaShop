$(document).ready(function(){
	if(jQuery("#options_clickandpledge_creditcard").length){
		document.getElementById("options_clickandpledge_creditcard").checked = true;
	    document.getElementById("options_clickandpledge_creditcard").disabled = true;
		document.getElementById("clickandpledge_hdncreditcard").value = "on";
	}
	if(jQuery("#options_clickandpledge_check").length){
		document.getElementById("options_clickandpledge_check").checked = true;
	document.getElementById("options_clickandpledge_check").disabled = true;
		document.getElementById("clickandpledge_hdnecheck").value = "on";
	}
	
	function limitText(limitField, limitCount, limitNum) { 
					if (limitField.val().length > limitNum) {
						limitField.val( limitField.val().substring(0, limitNum) );
						
						return false;
					} else {
					//	limitCount.html (limitNum - limitField.val().length);
						return false;
					}
				}
	
	jQuery('#clickandpledge_connectcode').parent().parent('div').hide();
	if(jQuery('#rec_clickandpledge_onetimeonly').is(':checked') == true && 
	   jQuery('#rec_clickandpledge_recurring').is(':checked') == true)
	   { 
		   jQuery('.clsdfltpayoptn').parent().parent('div').show();
	   }
		else
	   {
		   jQuery('.clsdfltpayoptn').parent().parent('div').hide();
	   }
		 
	if(jQuery("#rec_clickandpledge_recurring").is(':checked') == false)
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('.clsnoofpaymnts').parent().parent('div').hide();
		jQuery('.clsdfltnoofpaymnts').parent().parent('div').hide();
		jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide();
		jQuery('.clsdfltpayoptn').parent().parent('div').hide();
		jQuery('.clsdfltrectyp').parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
	}
	else
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('.clsnoofpaymnts').parent().parent('div').show();
		jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
		jQuery('.clsmaxnoofpaymnts').parent().parent('div').show();
		if(jQuery('#rec_clickandpledge_onetimeonly').is(':checked') == true){
		jQuery('.clsdfltpayoptn').parent().parent('div').show();}
		jQuery('.clsdfltrectyp').parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
	}
	if(jQuery('#rec_clickandpledge_installment').is(':checked') == true && 
	   jQuery('#rec_clickandpledge_subscription').is(':checked') == true & jQuery("#rec_clickandpledge_recurring").is(':checked') == true)
	   {
		   jQuery('.clsdfltrectyp').parent().parent('div').show();
	   }
		else
	   {
		   jQuery('.clsdfltrectyp').parent().parent('div').hide();
	   }
	
	if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false)
	{
	
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefiniteopen]').parent().parent('div').hide();
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefinite]').parent().parent('div').hide();
   
	}
	else
	{
	
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefiniteopen]').parent().parent('div').show();
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefinite]').parent().parent('div').show();
	}
	if(jQuery("#rec_clickandpledge_recurring").is(':checked') == true)
	{
	var noofpay1 = $('input[name=clickandpledge_numberofpayments]:checked').val();
		
					if(noofpay1 == "indefinite")
					{
						
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').hide();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
					}
					if(noofpay1 == "openfield")
					{
					  
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').show();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
				   }
					if(noofpay1 == "indefiniteopen")
					{
					  
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').show();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', true);
					}
					if(noofpay1 == "fixednumber")
					{
					   
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
					}
	}
	jQuery('#clickandpledge_org_info').keyup(function(){
		limitText(jQuery('#clickandpledge_org_info'),jQuery('#clickandpledge_org_info'),1500);
				});
	jQuery('#clickandpledge_terms_condition').keyup(function(){
		imitText(jQuery('#clickandpledge_terms_condition'),jQuery('#clickandpledge_terms_condition'),1500);
				});
	jQuery('#clickandpledge_org_info').keydown(function(){
	limitText(jQuery('#clickandpledge_org_info'),jQuery('#clickandpledge_org_info'),1500);
				});
	jQuery('#clickandpledge_terms_condition').keydown(function(){
	limitText(jQuery('#clickandpledge_terms_condition'),jQuery('#clickandpledge_terms_condition'),1500);
				});
	$('#CLICKANDPLEDGE_LOGIN_ID').on('change', function (e) {
		var  cnppsaccountid= jQuery('#CLICKANDPLEDGE_LOGIN_ID').val().trim();
		
		 	 jQuery.ajax({
				  type: "POST", 
				  url: baseDir + 'modules/clickandpledge/cnpajax.php',
				  data: 'method=cnpUserAccountListMethod&cnppsaccountid='+cnppsaccountid,
				  cache: false,
				  beforeSend: function() {
					
					jQuery("#clickandpledge_campaign").html("<option>Loading............</option>");
					},
					complete: function() {
					
					},	
				  success: function(htmlText) {
				
				  if(htmlText !== "")
				  {
					var res = htmlText.split("||");
					jQuery("#clickandpledge_campaign").html(res[0]);  
					jQuery('label[for="options_clickandpledge_creditcard"]').parent('div').html(res[1]);
					  jQuery('label[for="options_clickandpledge_check"]').parent('div').remove();
					  jQuery('label[for="options_clickandpledge_custompayment"]').parent('div').remove();
					
						  if(jQuery("#options_clickandpledge_custompayment").prop('checked') == true){

							jQuery('#clickandpledge_title').parent().parent('div').show();
							jQuery('#clickandpledge_refnumlabel').parent().parent('div').show();
							  admdefaultpayment();
						  }
						  else{	
							jQuery('#clickandpledge_title').parent().parent('div').hide();
							jQuery('#clickandpledge_refnumlabel').parent().parent('div').hide();

							  admdefaultpayment();
						  }
					
				  }
				  else
				  {
				  jQuery(".cnperror").show();
				  }
					
				  },
				  error: function(xhr, ajaxOptions, thrownError) {
					alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				  }
				});
	 return false;
	});
	/*if(jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
	}
	else
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		 if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false){
		   jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		 }
		 else{ jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
		 }
	}
	*/
/*	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == false && jQuery("#options_clickandpledge_check").is(':checked') == false && 
			jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
		
		jQuery('label[for="options_clickandpledge_creditcard"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').hide();
	}
	else if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true && 
			jQuery("#options_clickandpledge_check").is(':checked') == true && 
			jQuery("#clickandpledge_recurring_contribution_").is(':checked') == true )
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').show();
		 if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false){
		   jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		 }
		 else{ jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
		 }
		
	}
	*/
	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == false)
	{
		jQuery('#clickandpledge_title').parent().parent('div').hide();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').hide();
		
	}
	else
	{
		jQuery('#clickandpledge_title').parent().parent('div').show();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').show();
		
	}
	/**/
	/*if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false && jQuery("#clickandpledge_recurring_contribution_").is(':checked') == false)
	{
	jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();	
	}
	else if(jQuery("#rec_clickandpledge_subscription").is(':checked') == true && 
			jQuery("#clickandpledge_recurring_contribution_").is(':checked') == true && )
	{
	 jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();	
	}*/
	
	/**/
	jQuery('#clickandpledge_payment_method_default').html('');
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true)
	{
		if(jQuery("#clickandpledge_hdndfltpaymnt").val() == 'Creditcard')	defval_selected = "  selected";
	    else											                    defval_selected = "";
		jQuery('<option '+defval_selected+'>').val('Creditcard').text('Credit Card').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='Creditcard']").remove();
	}
	if(jQuery("#options_clickandpledge_check").is(':checked') == true)
	{
		if(jQuery("#clickandpledge_hdndfltpaymnt").val() == 'eCheck')	defval_selected = "  selected";
	    else											                    defval_selected = "";
		jQuery('<option '+defval_selected+'>').val('eCheck').text('eCheck').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='eCheck']").remove();
	}
	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == true)
	{ 
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				if(jQuery("#clickandpledge_hdndfltpaymnt").val() == splt[i])	defval_selected = "  selected";
				else											defval_selected = "";
				jQuery('<option '+defval_selected+'>').val(splt[i]).text(splt[i]).appendTo('#clickandpledge_payment_method_default');
				}
			}
		}
	}
	$("#configuration_form_submit_btn_1").click(function(){
		limitText(jQuery('#clickandpledge_org_info'),jQuery('#clickandpledge_org_info'),1500);	
	   limitText(jQuery('#clickandpledge_terms_condition'),jQuery('#clickandpledge_terms_condition'),1500);
		if(jQuery('#options_clickandpledge_custompayment').is(':checked') && jQuery.trim(jQuery('#clickandpledge_title').val()) == '') {
						alert('Please enter at least one payment method name');
						jQuery('#clickandpledge_title').val('');
						jQuery('#clickandpledge_title').focus();
						return false;	
					}
		          if(jQuery('input[name=clickandpledge_status]:checked').length <= 0)
					{
						alert('Please select API Mode');
						jQuery('#clickandpledge_status').focus();
						return false;
					}
				if(jQuery('input[name=clickandpledge_transactionmode]:checked').length <= 0)
					{
						alert('Please select Transaction Mode');
						jQuery('#clickandpledge_transactionmode').focus();
						return false;
					}
					var selected5 = 0;
					if(jQuery("#rec_clickandpledge_onetimeonly").prop('checked')) selected5++;
					if(jQuery("#rec_clickandpledge_recurring").prop('checked')) selected5++;
				
					if(selected5 == 0) {
						alert('Please select at least  one payment option');
						jQuery("#rec_clickandpledge_recurring").focus();
						return false;
					}
		if(jQuery('#rec_clickandpledge_recurring').is(':checked') == true) {
			
			var selected = 0;
			
					if(jQuery("#prdcty_clickandpledge_week").prop('checked')) selected++;
					if(jQuery("#prdcty_clickandpledge_2_weeks").prop('checked')) selected++;
					if(jQuery("#prdcty_clickandpledge_month").prop('checked')) selected++;
					if(jQuery("#prdcty_clickandpledge_2_months").prop('checked')) selected++;
					if(jQuery("#prdcty_clickandpledge_quarter").prop('checked')) selected++;
					if(jQuery("#prdcty_clickandpledge_6_months").prop('checked')) selected++;
					if(jQuery("#prdcty_clickandpledge_year").prop('checked')) selected++;
					if(selected == 0) {
						alert('Please select at least one period');
						jQuery("#prdcty_clickandpledge_week").focus();
						return false;
					}
					var selected2 = 0;
					if(jQuery("#rec_clickandpledge_installment").prop('checked')) selected2++;
					if(jQuery("#rec_clickandpledge_subscription").prop('checked')) selected2++;
				
					if(selected2 == 0) {
						alert('Please select at least one recurring type');
						jQuery("#rec_clickandpledge_subscription").focus();
						return false;
					}
					
					if(jQuery('input[name=clickandpledge_numberofpayments]:checked').length<=0)
					{
					   alert("Please select at least one option for number of payments");
					   jQuery("#clickandpledge_numberofpayments").focus();
					   return false;
					}
				if(jQuery('#clickandpledge_dfltnoofpaymnts').val() == "" && jQuery('input[name=clickandpledge_numberofpayments]:checked').val() == "fixednumber")
				{
				   alert("Please enter default number of payments");
				   jQuery("#clickandpledge_dfltnoofpaymnts").focus();
				   return false;														
				}
				if(jQuery('#clickandpledge_dfltnoofpaymnts').val() != "" && jQuery('#clickandpledge_dfltnoofpaymnts').val() <= 1)
						{
						   alert("Please enter default number of payments value greater than 1");
						   jQuery("#clickandpledge_dfltnoofpaymnts").focus();
						   return false;														
						}
				if(!parseInt(jQuery('#clickandpledge_dfltnoofpaymnts').val()) &&           					         jQuery('#clickandpledge_dfltnoofpaymnts').val() != "" )
				{
				   alert("Please enter an integer value only");
				   jQuery("#clickandpledge_dfltnoofpaymnts").focus();
				   return false;
				}
				if(jQuery('#clickandpledge_maxrecurrings').val() != "" && jQuery('#clickandpledge_maxrecurrings').val() <=1)
				{
				   alert("Please enter maximum number of installments allowed value greater than 1");
				   jQuery("#clickandpledge_maxrecurrings").focus();
				   return false;														
				}
				if(parseInt(jQuery('#clickandpledge_maxrecurrings').val()) < parseInt(jQuery('#clickandpledge_dfltnoofpaymnts').val()))
				{
					alert("Maximum number of installments allowed to be greater than or equal to default number of payments");
					jQuery('#clickandpledge_dfltnoofpaymnts').focus();
					return false;
				}
				if(!parseInt(jQuery('#clickandpledge_maxrecurrings').val()) && jQuery('#clickandpledge_maxrecurrings').val() != "" )
				{
				   alert("Please enter an integer value only");
				   jQuery("#clickandpledge_maxrecurrings").focus();
				   return false;														
				}
				if(jQuery('#rec_clickandpledge_installment').is(':checked') &&     !jQuery('#rec_clickandpledge_subscription').is(':checked'))
				{
				
					if(jQuery('#clickandpledge_dfltnoofpaymnts').val() !=""  && jQuery('#clickandpledge_dfltnoofpaymnts').val() > 998 &&
					jQuery("#rec_clickandpledge_recurring").is(':checked') == true)
					{
						   alert("Please enter value between 2 to 998 for installment");
						   jQuery("#clickandpledge_dfltnoofpaymnts").focus();
						   return false;
					}
					if(jQuery('#clickandpledge_maxrecurrings').val() !=""  && jQuery('#clickandpledge_maxrecurrings').val() > 998 && jQuery("#rec_clickandpledge_recurring").is(':checked') == true)
					{
						   alert("Please enter value between 2 to 998 for installment");
						   jQuery("#clickandpledge_maxrecurrings").focus();
						   return false;
					}
				}
				else if(jQuery('#rec_clickandpledge_installment').is(':checked') && jQuery('#rec_clickandpledge_subscription').is(':checked'))
				{
					
					if(jQuery('#clickandpledge_recurringtype_default').val() === "Installment" && jQuery('#clickandpledge_dfltnoofpaymnts').val() > 998 && 
					   jQuery("#rec_clickandpledge_recurring").is(':checked') === true && 
					   jQuery('input[name=clickandpledge_numberofpayments]:checked').val() !== "indefinite_openfield")
					{
						   alert("Please enter value between 2 to 998 for installment");
						   jQuery("#clickandpledge_dfltnoofpaymnts").focus();
						   return false;
					}
					/*if(jQuery('#clickandpledge_recurringtype_default').val() == "Installment" && 
					   jQuery('#clickandpledge_maxrecurrings').val() > 998 &&
					   jQuery("#rec_clickandpledge_recurring").is(':checked') == true && 
					   jQuery('input[name=clickandpledge_numberofpayments]:checked').val() != "indefinite_openfield")
					{
						  alert("Please enter value between 2 to 998 for installment");
						   jQuery("#clickandpledge_maxrecurrings").focus();
						   return false;
					}*/
				}
		}
	});
	$("#configuration_form_submit_btn").click(function(){
		
		if($("#configuration_form_submit_btn").text().trim() === "Get the Code"){
			var cnpemail = $("#clickandpledge_connectusername").val();
			if(cnpemail !="" && validateEmail(cnpemail) )
				{ 
				  $.ajax({
					method: "POST",
					url : baseDir + 'modules/clickandpledge/cnpajax.php',
					data: 'method=cnpGetCodeMethod&cnpemailid='+cnpemail,
					success: function (data) {

						   if(jQuery.parseJSON(data) === "Code has been sent successfully")
							  {

								  jQuery('#clickandpledge_connectcode').parent().parent('div').show();
								  jQuery("#configuration_form_submit_btn").prop('value', 'Login');
								  jQuery("#configuration_form_submit_btn").html('Login');

							 // jQuery(".text-danger").html("");
							  jQuery(".help-block").html("");
							//  jQuery(".cnperror").show();
					
				 jQuery(".help-block").html("Please enter the code sent to your email");
				 jQuery(".help-block").css({ 'color': 'green' });
				  }
				  else if(data !="") 
				  {
				  	 alert("Sorry but we cannot find the email in our system. Please try again");
				  	 jQuery(".help-block").html(data);
				     jQuery(".help-block").css({ 'color': 'red' });
				  }
					
				  }
        
    });
				}
			else{
				 alert("Please enter valid connect user name");
				  jQuery('#clickandpledge_connectusername').focus();
				  return false;
			}
		}
		
		if($("#configuration_form_submit_btn").text().trim() === "Login"){
			 var cnpemailid = jQuery('#clickandpledge_connectusername').val().trim();
				  var cnpcode = jQuery('#clickandpledge_connectcode').val().trim();
				 if(cnpemailid !== "" && cnpcode !== "")
				 {
					 $.ajax({
        method: "POST",
		url : baseDir + 'modules/clickandpledge/cnpajax.php',
        data: 'method=cnpGetAccountsMethod&cnpemailid='+cnpemailid+'&cnpcode='+cnpcode,
        success: function (data) {
			   if(data !== "error")
				  {
					  jQuery('#clickandpledge_connectusername').val("");
					  jQuery('#clickandpledge_connectcode').val("");
  				  	  jQuery('#clickandpledge_connectcode').parent().parent('div').hide();
					  jQuery("#configuration_form_submit_btn").prop('disabled', '');
				      jQuery("#configuration_form_submit_btn").prop('value', 'Get the code');
					  jQuery("#configuration_form_submit_btn").html('Get the code');
					  location.reload();
				  }
				  else if(data !="") 
				  {
				  
				 	
				   jQuery(".help-block").html("Invalid code");
					  jQuery(".help-block").css({ 'color': 'red' });
				  }
					
				  }
        
    });
				 }
		}
		return false;
	});
	
 $("#rec_clickandpledge_recurring").click(function(){
	 
 		if(jQuery("#rec_clickandpledge_recurring").is(':checked') == false)
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('.clsnoofpaymnts').parent().parent('div').hide();
		jQuery('.clsdfltnoofpaymnts').parent().parent('div').hide();
		jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide();
		jQuery('.clsdfltpayoptn').parent().parent('div').hide();
		jQuery('.clsdfltrectyp').parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
	}
	else
	{ 
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('.clsnoofpaymnts').parent().parent('div').show();
		jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
		 if($('input[name=clickandpledge_numberofpayments]:checked').val() === "fixednumber")
			 {
					jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide(); 
			 }
		 else{
			jQuery('.clsmaxnoofpaymnts').parent().parent('div').show();}
		jQuery('.clsdfltpayoptn').parent().parent('div').show();
		jQuery('.clsdfltrectyp').parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
	}
			
 });
	$("#rec_clickandpledge_onetimeonly").click(function(){
	if(jQuery('#rec_clickandpledge_onetimeonly').is(':checked') == true && 
	   jQuery('#rec_clickandpledge_recurring').is(':checked') == true)
	   {
		   jQuery('.clsdfltpayoptn').parent().parent('div').show();
	   }
		else
	   {
		   jQuery('.clsdfltpayoptn').parent().parent('div').hide();
	   }
		 });
	$(".clsrecmthd").click(function(){
	if(jQuery('#rec_clickandpledge_installment').is(':checked') == true && 
	   jQuery('#rec_clickandpledge_subscription').is(':checked') == true && jQuery("#rec_clickandpledge_recurring").is(':checked') == true)

	   {
		   jQuery('.clsdfltrectyp').parent().parent('div').show();
	   }
		else
	   {
		   jQuery('.clsdfltrectyp').parent().parent('div').hide();
	   }
		 });
	
 $("#rec_clickandpledge_subscription").click(function(){
	if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false)
	{
	
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefiniteopen]').parent().parent('div').hide();
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefinite]').parent().parent('div').hide();
   		jQuery("#clickandpledge_dfltnoofpaymnts").val('');
		jQuery("#clickandpledge_maxrecurrings").val('');
		jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
		jQuery('input[name="clickandpledge_numberofpayments"]').prop('checked', false);
	
	}
	else
	{
	
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefiniteopen]').parent().parent('div').show();
		jQuery('input:radio[name=clickandpledge_numberofpayments][value=indefinite]').parent().parent('div').show();
	}
 });
 jQuery(".clsnoofpaymnts").click(function(){

var noofpay = $('input[name=clickandpledge_numberofpayments]:checked').val();

					if(noofpay == "indefinite")
					{
						jQuery("#clickandpledge_dfltnoofpaymnts").val('');
						jQuery("#clickandpledge_maxrecurrings").val('');
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').hide();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
					}
					if(noofpay == "openfield")
					{
					    jQuery("#clickandpledge_dfltnoofpaymnts").val('');
						jQuery("#clickandpledge_maxrecurrings").val('');
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').show();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
				   }
					if(noofpay == "indefiniteopen")
					{
					    jQuery("#clickandpledge_dfltnoofpaymnts").val('');
						jQuery("#clickandpledge_maxrecurrings").val('');
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').show();
						jQuery("#clickandpledge_dfltnoofpaymnts").val('999');
						jQuery("#clickandpledge_maxrecurrings").val('999');
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', true);
					}
					if(noofpay == "fixednumber")
					{
					    jQuery("#clickandpledge_dfltnoofpaymnts").val('');
						jQuery("#clickandpledge_maxrecurrings").val('');
						jQuery('.clsdfltnoofpaymnts').parent().parent('div').show();
						jQuery('.clsmaxnoofpaymnts').parent().parent('div').hide();
						jQuery('#clickandpledge_maxrecurrings').attr('readonly', false);
					}
 });
   $("#options_clickandpledge_custompayment").click(function(){
 	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == false)
	{
		jQuery('#clickandpledge_title').parent().parent('div').hide();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').hide();
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				$("#clickandpledge_payment_method_default option[value='"+splt[i]+"']").remove();
				
				}
			}
		}
	}
	else
	{ 
		jQuery('#clickandpledge_title').parent().parent('div').show();
		jQuery('#clickandpledge_refnumlabel').parent().parent('div').show();
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				if(jQuery("#clickandpledge_hdndfltpaymnt").val() == splt[i])	defval_selected = "  selected";
				else											                defval_selected = "";
				jQuery('<option '+defval_selected+'>').val(splt[i]).text(splt[i]).appendTo('#clickandpledge_payment_method_default');
				}
			}
		}
		
	}
			
 });         
 $("#options_clickandpledge_creditcard").click(function(){
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true)
	{
		jQuery('<option >').val('Creditcard').text('Credit Card').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='Creditcard']").remove();
	}
	chkrecSec();
   });   
  $("#options_clickandpledge_check").click(function(){
	if(jQuery("#options_clickandpledge_check").is(':checked') == true)
	{
		jQuery('<option >').val('eCheck').text('eCheck').appendTo('#clickandpledge_payment_method_default');
	}
	else
	{
		$("#clickandpledge_payment_method_default option[value='eCheck']").remove();
	}
	chkrecSec();
   }); 
 
   $("#clickandpledge_title").change(function(){
	jQuery('#clickandpledge_payment_method_default').html('');
	if(jQuery("#options_clickandpledge_creditcard").is(':checked') == true)
	{
			jQuery('<option >').val('Creditcard').text('Credit Card').appendTo('#clickandpledge_payment_method_default');
	}
	if(jQuery("#options_clickandpledge_check").is(':checked') == true)
	{
		jQuery('<option >').val('eCheck').text('eCheck').appendTo('#clickandpledge_payment_method_default');
	}
	if(jQuery("#options_clickandpledge_custompayment").is(':checked') == true)
	{
		var CustomPaymentTitles = jQuery("#clickandpledge_title").val();//alert(CustomPaymentTitles);
		var splt = "";
		if(CustomPaymentTitles != "")
		{
			splt = CustomPaymentTitles.split(';');
			for(var i=0;i < splt.length; i++)
			{
				var spltVal = splt[i].trim();
				if( spltVal !="" ){
				if(jQuery("#clickandpledge_hdndfltpaymnt").val() == splt[i])	defval_selected = "  selected";
				else											                defval_selected = "";
				jQuery('<option '+defval_selected+'>').val(splt[i]).text(splt[i]).appendTo('#clickandpledge_payment_method_default');
				}
			}
		}
	}
	
   }); 
	jQuery('#clickandpledge_connectusername').on('keypress', function(e) {
        if (e.which == 32)
            return false;
        });
	function validateEmail($email) { 
		  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		  return emailReg.test( $email );
		}
   function admdefaultpayment() { 
					var paymethods = [];
					var paymethods_titles = [];
					var str = '';
					var defaultval = jQuery('#clickandpledge_payment_method_default').val();
					if(jQuery('#options_clickandpledge_creditcard').val()!=""){						        paymethods.push('CreditCard');
						paymethods_titles.push('Credit Card');
					}
					if(jQuery('#options_clickandpledge_check').val()!="") {
						paymethods.push('eCheck');
						paymethods_titles.push('eCheck');
					}
					
					if(jQuery('#options_clickandpledge_custompayment').is(':checked')) {
						jQuery('#clickandpledge_title').closest('tr').show();
						jQuery('#clickandpledge_refnumlabel').closest('tr').show();
						
						var titles = jQuery('#clickandpledge_title').val();
						var titlesarr = titles.split(";");
						for(var j=0;j < titlesarr.length; j++)
						{
							if(titlesarr[j] !=""){
								paymethods.push(titlesarr[j]);
								paymethods_titles.push(titlesarr[j]);
							}
						}
					} else {
						jQuery('#clickandpledge_title').closest('tr').hide();
						jQuery('#clickandpledge_refnumlabel').closest('tr').hide();
					}
					
					if(paymethods.length > 0) {
						for(var i = 0; i < paymethods.length; i++) {
							if(paymethods[i] == defaultval) {
							str += '<option value="'+paymethods[i]+'" selected>'+paymethods_titles[i]+'</option>';
							} else {
							str += '<option value="'+paymethods[i]+'">'+paymethods_titles[i]+'</option>';
							}
						}
					} else {
					 str = '<option selected="selected" value="">Please select</option>';
					}
					jQuery('#clickandpledge_payment_method_default').html(str);
				}
   function chkrecSec()
   {
	   if(jQuery("#options_clickandpledge_creditcard").is(':checked') == false && jQuery("#options_clickandpledge_check").is(':checked') == false)
	{
		
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').hide();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').hide();
		jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
	   jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').hide();
	}
	else
	{
		jQuery('label[for="prdcty_clickandpledge_week"]').parent().parent().parent('div').show();
		jQuery('label[for="rec_clickandpledge_installment"]').parent().parent().parent('div').show();
		jQuery('label[for="clickandpledge_recurring_contribution_"]').parent().parent().parent('div').show();
		 if(jQuery("#rec_clickandpledge_subscription").is(':checked') == false){
		   jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').hide();
		 }
		 else{ jQuery('label[for="ind_clickandpledge_indefinite"]').parent().parent().parent('div').show();
		 }
		
	}
   }
});
