<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{authorizeaim}prestashop>authorizeaim_1814fc250eea61e13aa95e81b61bf72a'] = 'Paga con authorizeaim';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_442155d68aea78b4ef707796d76ca48c'] = 'logo visa';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_f65943f43529e119969e533dc6f691f9'] = 'logo mastercard';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_2937b5dab08029b1055b37c98a98d740'] = 'logo discover';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_3b8a6fa58a71e7448c264c9dc61e6904'] = 'logo american express';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_1edaf23879c3b52a8df80069d2af3cef'] = 'Pagamento sicuro con carta di credito con Authorize.net';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_f11b368cddfe37c47af9b9d91c6ba4f0'] = 'Nome completo';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_a44217022190f5734b2f72ba1e4f8a79'] = 'Numero di carta';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_8c1279db4db86553e4b9682f78cf500e'] = 'Data di scadenza';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_60a104dc50579d60cbc90158fada1dcf'] = 'CVV';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_40566b26dcc126bce704f2c1d622a6a3'] = 'Convalida ordine';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_9286982d71addb45ad3a9472282f2c69'] = 'Il tuo numero di carta è falso';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_cb313e911b15b21b57f4fc7b53058e4f'] = 'Ricevi il pagamento con Authorize.net';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurazione aggiornata';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_6a26f548831e6a8c26bfbbd9f6ec61e0'] = 'Aiuto';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_11a4b229c0e206b831f729572618553f'] = 'Nel tuo pannello admin PrestaShop';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_bc6781f2b59d4e973bd0075baab62a40'] = 'Riempi il campo ID Login con quello fornito da Authorize.net';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_95eb440b753d6505aad5c3f72b50eec9'] = 'Riempire il campo chiave con la chiave di transazione fornita da Authorize.net';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_f3ef34226d51e9ca88eaa2f20d7ffb91'] = 'ID Login ';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_897356954c2cd3d41b221e3f24f99bba'] = 'Chiave';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_1ee1c44c2dc81681f961235604247b81'] = 'Modalità:';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_756d97bb256b8580d4d71ee0c547804e'] = 'Produzione';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_0cbc6611f5540bd0809a388dc95a615b'] = 'Test';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_291cdb0a8abb42484f5d44dc20540ce6'] = 'Carte di credito:';
$_MODULE['<{authorizeaim}prestashop>authorizeaim_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aggiorna le impostazioni';
$_MODULE['<{authorizeaim}prestashop>hookorderconfirmation_2e2117b7c81aa9ea6931641ea2c6499f'] = 'Il tuo ordine';
$_MODULE['<{authorizeaim}prestashop>hookorderconfirmation_75fbf512d744977d62599cc3f0ae2bb4'] = 'è completo.';
$_MODULE['<{authorizeaim}prestashop>hookorderconfirmation_30163d8fc3068e8297e7ab5bf32aec87'] = 'Il tuo ordine verrà inviato al più presto.';
$_MODULE['<{authorizeaim}prestashop>hookorderconfirmation_0db71da7150c27142eef9d22b843b4a9'] = 'Per eventuali domande o per ulteriori informazioni, contatta la nostra';
$_MODULE['<{authorizeaim}prestashop>hookorderconfirmation_64430ad2835be8ad60c59e7d44e4b0b1'] = 'assistenza clienti';
$_MODULE['<{authorizeaim}prestashop>hookorderconfirmation_8de637e24570c1edb0357826a2ad5aea'] = 'Abbiamo notato un problema con il tuo ordine. Se pensi che questo sia un errore, contatta la nostra';

?>