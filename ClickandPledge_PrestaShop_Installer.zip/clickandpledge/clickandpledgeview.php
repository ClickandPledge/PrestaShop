<?php
$add = '';
if(isset($_POST['recurring']) && $_POST['recurring'] == 'yes')
{ ?>
<script type="text/javascript">var recurring_units= new Array(); recurring_units = ["<?php  echo $_POST['recurring_units_week']; ?>","<?php  echo $_POST['recurring_units_week2']; ?>","<?php  echo $_POST['recurring_units_month']; ?>","<?php  echo $_POST['recurring_units_month2']; ?>","<?php  echo $_POST['recurring_units_quarter']; ?>","<?php  echo $_POST['recurring_units_month6']; ?>","<?php  echo $_POST['recurring_units_year']; ?>"]; var indefinite = "<?php echo $_POST['indefinite'];?>"</script>
<?php
if(isset($_POST['recurring']) && $_POST['recurring'] == 'yes' && $_POST['cartfinalamount'] > 0) { 
$add = '<div id="myElementId"><h3>Payment Options</h3><div class="payment_options"><input type="radio" id="is_recurring" name="is_recurring" value="0" checked="checked" onclick="recurring_setup(this.value);">&nbsp;<label class="option" for="is_recurring"><span></span> I want to make a one-time payment</div><div class="payment_options"><input type="radio" id="recurring-manytime" name="is_recurring" value="1" onclick="recurring_setup(this.value,\''.$_POST['recurring_installment'].'\',\''.$_POST['recurring_subscription'].'\',recurring_units,indefinite);">&nbsp;<label class="option" for="recurring-manytime"><span></span> I want to make a recurring payment</label>
</div><div id="method_display"></div>';
$add .= '</div>';
}
}
if(isset($_POST['payment_methods']) && $_POST['payment_methods'] == 'Creditcard')
{
?>
				<div id="card_fields">
				<?php echo $add;?>
				<div class="card_fields">
					<h5>Card Information</h5>
					<label>Name on card <span class="required">*</span></label>
					<input type="text" name="name" id="name" size="20" maxlength="50" />
					<div class="clearfix"></div>
					<label>Credit Card Number <span class="required">*</span></label>
					<input type="text" id="ccn" name="x_card_num" size="20"  maxlength="17" autocomplete="Off" style="float:left"/>
					<div style="clear:both"></div>
					<label>Expiration date <span class="required">*</span></label>
					<select name="x_exp_date_m" id="x_exp_date_m">
					<?php
						for($i=1;$i<=12;$i++){
						$month_num =  date("m");
						$all =date("m",strtotime(date('Y-'.$i.'-01')));
									if($all == $month_num){$selected = 'selected';}else{$selected='';}
		               echo	'<option value="'.$all.'" '.$selected.'>'.date("F",strtotime(date('Y-'.$i.'-01'))).'</option>';
								 }
					   echo '</select>';
						?>
					 /
					<select name="x_exp_date_y" id="x_exp_date_y">
					<?php
						for($i=0;$i<=10;$i++){
						$year = date('Y')+$i;
						$year_two = date('y')+$i;
						echo '<option value="'.$year_two.'">'.$year.'</option>';
							}
						echo '</select>'; ?>
					<div class="clearfix"></div>
					<label>Card Verification (CVV) <span class="required">*</span></label>
					<input type="text" name="x_card_code" id="x_card_code" size="4" maxlength="4" />&nbsp
						<img src="<?php echo $_POST['mod_url'];?>help.png" id="cvv_help" title="the 3 last digits on the back of your credit card" alt="" onclick="document.getElementById('cvv_help_img').style.display='block'" />
						<div class="clearfix"></div>
				    <div class="cvv_help_img" id="cvv_help_img" style="display: none;margin-left: 211px;"><img src="<?php echo $_POST['mod_url'];?>cvv.png" alt="cvv" /></div>
					<!--<div id="divMsg"  >
					<input type="button" id="asubmit_credit_card" value="Confirm order"  class="button" onclick="return credit_card_valid();"/>
					</div>-->
				</div>
				</div>
<?php } if(isset($_POST['payment_methods']) && $_POST['payment_methods'] == 'eCheck') { ?>

				<div id="check_fields">
					<?php echo $add;?>
				<div class="card_fields">
					<h5>eCheck Information</h5>
					<label>Routing Number <span class="required">*</span></label>
					<input type="text" name="RoutingNumber" id="RoutingNumber" size="20" maxlength="9" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Check Number <span class="required">*</span></label>
					<input type="text" id="CheckNumber" name="CheckNumber" size="20" maxlength="10" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Account Number <span class="required">*</span></label>
				  <input type="text" id="AccountNumber" name="AccountNumber" size="20" maxlength="17" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Retype Account Number <span class="required">*</span></label>
					<input type="text" name="RetypeAccountNumber" id="RetypeAccountNumber" size="20" maxlength="17" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Account Type</label>
					<select name="AccountType" id="AccountType">
						<option value="SavingsAccount">Savings Account</option>
						<option value="CheckingAccount">Checking Account</option>
					</select>
					<div class="clearfix"></div>
					<label>Check Type</label>
					<select name="CheckType" id="CheckType">
						<option value="Company">Company</option>
						<option value="Personal">Personal</option>
					</select>
					<div class="clearfix"></div>
					<label>Name on Account <span class="required">*</span></label>
					<input type="text" name="NameOnAccount" id="NameOnAccount" size="20" maxlength="100" autocomplete="Off"/>
					<div class="clearfix"></div>
					<?php }
					if(isset($_POST['payment_methods']) && $_POST['payment_methods'] != 'Creditcard' && $_POST['payment_methods'] != 'eCheck') {
					if($_POST['refnumlabel'] != "")
					{
					?>
						<h3><?php echo $_POST['refnumlabel']; ?> </h3>
						<input type="text"  id="clickandpledge_cp_ReferenceNumber" name="clickandpledge_cp_ReferenceNumber" placeholder="<?php echo $_POST['refnumlabel']?>" maxlength="50"/>
						<div class="clearfix"></div>
					<?php } ?>
				</div>
				</div>
<?php } ?>
