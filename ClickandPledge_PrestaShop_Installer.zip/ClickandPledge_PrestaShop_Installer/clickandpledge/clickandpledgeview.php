<?php
$add = '';
if(isset($_POST['recurring']) && $_POST['recurring'] == 'yes')
{ 
$recurring_units = array();
if($_POST['recurring_units_week']!=""){array_push($recurring_units,$_POST['recurring_units_week']);}
if($_POST['recurring_units_week2']!=""){array_push($recurring_units,$_POST['recurring_units_week2']);}
if($_POST['recurring_units_month']!=""){array_push($recurring_units,$_POST['recurring_units_month']);}
if($_POST['recurring_units_month2']!=""){array_push($recurring_units,$_POST['recurring_units_month2']);}
if($_POST['recurring_units_quarter']!=""){array_push($recurring_units,$_POST['recurring_units_quarter']);}
if($_POST['recurring_units_month6']!=""){array_push($recurring_units,$_POST['recurring_units_month6']);}
if($_POST['recurring_units_year']!=""){array_push($recurring_units,$_POST['recurring_units_year']);}
$defalutpaymentoption = $_POST['defalutpaymentoption'];
$dfltrecurringsubscription = $_POST['dfltrecurringsubscription'];?>
<script language="javascript">
	manageshowhideRecpay();manageRecpay();
function manageshowhideRecpay() {
				if(jQuery('#is_recurring:checked').val() == 0) {	
						jQuery('#dvrecurtyp').hide();
						jQuery('#dvprdcty').hide();
						jQuery('#dvnoofpaymnts').hide();
										
					} else {	
						jQuery('#dvrecurtyp').show();
					    jQuery('#dvprdcty').show();	
						jQuery('#dvnoofpaymnts').show();
					
						
						}
						manageRecpay();
					}
function manageRecpay() { 
					if(jQuery('#is_recurring:checked').val() == 1) {
					
					 
					
					 if(jQuery('#clickandpledge_RecurringMethod').val() == 'Installment' && jQuery('#hdnrecdtl').val() == 'indefiniteopen') {
					 		
					if(jQuery('#clickandpledge_noofpayments').val() != '' && jQuery('#clickandpledge_noofpayments').val() <= 998){jQuery('#clickandpledge_noofpayments').val(jQuery('#clickandpledge_noofpayments').val());}else{jQuery('#clickandpledge_noofpayments').val('998');}
						
						} 
						if(jQuery('#clickandpledge_RecurringMethod').val() == 'Subscription' &&  jQuery('#hdnrecdtl').val() == 'indefiniteopen') {
						if(jQuery('#clickandpledge_noofpayments').val() != ''){jQuery('#clickandpledge_noofpayments').val(jQuery('#clickandpledge_noofpayments').val());}else{jQuery('#clickandpledge_noofpayments').val('999');}			
						} 
					
					}
					}
				jQuery("#clickandpledge_RecurringMethod").change(function(){
					if(jQuery("#clickandpledge_RecurringMethod").val() == "Installment" && jQuery("#clickandpledge_noofpayments").val() == "999")
						{
							jQuery("#clickandpledge_noofpayments").val('998');
							return false;
						}
				});
	
</script>
<?php
	$add .="";
if(isset($_POST['recurring']) && $_POST['recurring'] == 'yes' && $_POST['cartfinalamount'] > 0) { 
 if(isset($_POST['onetimeonly']) && $_POST['onetimeonly'] == 'yes' ) { 
	
$add .= '<div id="myElementId"><h3>Payment Options</h3><div class="payment_options"><input type="radio" id="is_recurring" name="is_recurring" value="0"';
	if($defalutpaymentoption == "One Time Only"){
	$add .= 'checked="checked"';	
	}
	$add .= ' onclick="manageshowhideRecpay();">&nbsp;<label class="option" for="is_recurring"><span></span> One Time Only</div><div class="payment_options"><input type="radio" id="recurring-manytime" name="is_recurring" value="1"';
	if($defalutpaymentoption == "Recurring"){
	$add .= 'checked="checked"';	
	}	$add .= ' onclick="manageshowhideRecpay();">&nbsp;<label class="option" for="recurring-manytime"><span></span> Recurring</label>
	
</div><div id="method_display"></div>';
}
else
	{
	$add .= '<div id="myElementId"><input type="hidden" name="is_recurring" id="is_recurring" value="1" />';
	}

$add .= '</div><div class="form-group" id="dvrecurtyp" >

<label for="clickandpledge_cart_number">Recurring type</label>
<select id="clickandpledge_RecurringMethod" name="clickandpledge_RecurringMethod" onchange="manageRecpay();">';
if($_POST['recurring_installment'] !=""){

$add .='<option value="'.$_POST['recurring_installment'].'"';
	if($dfltrecurringsubscription == "Installment"){
	$add .= 'checked="checked"';	
	}
	$add .=">".$_POST['recurring_installment'].'</option>';
}
if($_POST['recurring_subscription'] !=""){

$add .='<option value="'.$_POST['recurring_subscription'].'"';
	if($dfltrecurringsubscription == "Subscription"){
	$add .= 'selected="selected"';	
	}
	$add .= ">".$_POST['recurring_subscription'].'</option>';
}
	$add .='</select></div><div class="form-group" id="dvprdcty" >
<label for="clickandpledge_cart_number">Periodicity</label>
	<select name="Periodicity" id="Periodicity">';
	for ($inc=0;$inc < count($recurring_units);$inc++)
		{
		 $add .= '<option value="'.$recurring_units[$inc].'">'.$recurring_units[$inc].'</option>';
		}
$add .='</select></div><input type="hidden" name="hdnrecdtl" id="hdnrecdtl" value="'.$_POST['numberofpayments'].'"><input type="hidden" name="hdnmaxnopaymnts" id="hdnmaxnopaymnts" value="'.$_POST['maxnumberofpayments'].'"><div class="form-group" id="dvnoofpaymnts">
<label for="clickandpledge_cart_number">Number of Payments</label>';
	if($_POST['numberofpayments'] =="indefinite")
	{
		$add .='<input type="hidden" name="clickandpledge_noofpayments" id="clickandpledge_noofpayments" value="999"/>Indefinite Only';
	}
	elseif($_POST['numberofpayments'] == "fixednumber"){
		$add .='<input type="hidden" name="clickandpledge_noofpayments" id="clickandpledge_noofpayments" value="'.$_POST['dfltnumberofpayments'].'"/>'.$_POST['dfltnumberofpayments'];
	}
	else{
		$add .='<input type="text" name="clickandpledge_noofpayments" id="clickandpledge_noofpayments" value="'.$_POST['dfltnumberofpayments'].'"/>';
	}
	$add .='</div>';

}
}
if(isset($_POST['payment_methods']) && $_POST['payment_methods'] == 'CreditCard')
{
?>
				<div id="card_fields">
					<?php if($_POST['transactionmode'] == 'Test'){?>
					<script>	jQuery( document ).ready(function() {
							
			var d = new Date();
			var n = d.getFullYear() + 1;
				var yr =n.toString().substr(-2)
			//document.getElementById('#ccn').value = "4111111111111111";
			
			//jQuery("#ccn").prop("readonly", true);
			//jQuery("#ccn").css({"background-color": "#f4f4f4"});
			 document.cnp_form.ccn.value="4111111111111111";
							document.cnp_form.ccn.readOnly = true;
			 document.cnp_form.x_exp_date_m.value="06";
								document.cnp_form.x_exp_date_m.readOnly = true;
			 document.cnp_form.x_exp_date_y.value=yr;
								document.cnp_form.x_exp_date_y.readOnly = true;
			 document.cnp_form.x_card_code.value=123;
								document.cnp_form.x_card_code.readOnly = true;
						/*	"4111111111111111";
			document.getElementById('#x_exp_date_m').value = "06";
			jQuery("#x_exp_date_m").prop("readonly", true);
			document.getElementById('#x_exp_date_y').value = n ;
			jQuery("#x_exp_date_y").prop("readonly", true);
			document.getElementById('#x_card_code').value = "123";
			jQuery("#x_card_code").prop("readonly", true);				*/					});</script>
				
					<?php }?>
				<?php echo $add;?>
				<div class="card_fields">
					<h5>Card Information</h5>
					<div>
		<?php 
		if($_POST['cnp_amex'] !="")	 {?>&nbsp;<img src='<?php echo $_POST['mod_url'];?>amex.jpg'  border=0/><?php  }
		if($_POST['cnp_amex'] !="")
		 { ?>
			 &nbsp;<img src='<?php echo $_POST['mod_url'];?>mastercard.gif' title='MasterCard' alt='MasterCard'/>
		<?php  }
		if($_POST['cnp_master']!="")
		 { ?>
			 <img src='<?php echo $_POST['mod_url'];?>visa.jpg' title='Visa' alt='Visa'/>
		<?php  }
		if($_POST['cnp_discover'] !="")
		 {?>
			 &nbsp;<img src='<?php echo $_POST['mod_url'];?>discover.jpg' title='Discover' alt='Discover'/>
		<?php  }
		if($_POST['cnp_jcb']!="")
		 {?>
			&nbsp;<img src='<?php echo $_POST['mod_url'];?>JCB.jpg' title='JCB' alt='JCB'/>
		<?php  } ?></div>
					<label>Name on card <span class="required">*</span></label>
					<input type="text" name="name" id="name" size="20" maxlength="50" />
					<div class="clearfix"></div>
					<label>Credit Card Number <span class="required">*</span></label>
					<input type="text" id="ccn" name="x_card_num" size="20"  maxlength="17" autocomplete="Off" style="float:left"/>
					<div style="clear:both"></div>
					<label>Expiration date <span class="required">*</span></label>
					<select name="x_exp_date_m" id="x_exp_date_m">
					<?php
						for($i=1;$i<=12;$i++){
						$month_num =  date("m");
						$all =date("m",strtotime(date('Y-'.$i.'-01')));
									if($all == $month_num){$selected = 'selected';}else{$selected='';}
		               echo	'<option value="'.$all.'" '.$selected.'>'.date("F",strtotime(date('Y-'.$i.'-01'))).'</option>';
								 }
					   echo '</select>';
						?>
					 /
					<select name="x_exp_date_y" id="x_exp_date_y">
					<?php
						for($i=0;$i<=20;$i++){
						$year = date('Y')+$i;
						$year_two = date('y')+$i;
						echo '<option value="'.$year_two.'">'.$year.'</option>';
							}
						echo '</select>'; ?>
					<div class="clearfix"></div>
					<label>Card Verification (CVV) <span class="required">*</span></label>
					<input type="text" name="x_card_code" id="x_card_code" size="4" maxlength="4" />&nbsp
						<img src="<?php echo $_POST['mod_url'];?>help.png" id="cvv_help" title="the 3 last digits on the back of your credit card" alt="" onclick="document.getElementById('cvv_help_img').style.display='block'" />
						<div class="clearfix"></div>
				    <div class="cvv_help_img" id="cvv_help_img" style="display: none;margin-left: 211px;"><img src="<?php echo $_POST['mod_url'];?>cvv.png" alt="cvv" /></div>
					<!--<div id="divMsg"  >
					<input type="button" id="asubmit_credit_card" value="Confirm order"  class="button" onclick="return credit_card_valid();"/>
					</div>-->
				</div>
				</div>
<?php } if(isset($_POST['payment_methods']) && $_POST['payment_methods'] == 'eCheck') { ?>

				<div id="check_fields"><?php if($_POST['transactionmode'] == 'Test'){?>
					<script>	jQuery( document ).ready(function() {
			jQuery("#AccountType").prop("disabled", true);
			jQuery("#AccountType").css({"background-color": "#f4f4f4"});
			jQuery("#NameOnAccount").prop("disabled", true);
			jQuery("#NameOnAccount").css({"background-color": "#f4f4f4"});
			
			jQuery("#CheckType").prop("disabled", true);
			jQuery("#CheckType").css({"background-color": "#f4f4f4"});
			jQuery("#CheckNumber").prop("disabled", true);
			jQuery("#CheckNumber").css({"background-color": "#f4f4f4"});
			jQuery("#RoutingNumber").prop("disabled", true);
			jQuery("#RoutingNumber").css({"background-color": "#f4f4f4"});
			jQuery("#AccountNumber").prop("disabled", true);
			jQuery("#AccountNumber").css({"background-color": "#f4f4f4"});
			jQuery("#RetypeAccountNumber").prop("disabled", true);
			jQuery("#RetypeAccountNumber").css({"background-color": "#f4f4f4"});
																	});</script>
					<h4><span style="color: red">eCheck does not support test transactions</span></h4>
					<?php }?>
					<?php echo $add;?>
				<div class="card_fields">
					
					<h5>eCheck Information</h5>
					<label>Name on Account <span class="required">*</span></label>
					<input type="text" name="NameOnAccount" id="NameOnAccount" size="20" maxlength="100" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Check Number <span class="required">*</span></label>
					<input type="text" id="CheckNumber" name="CheckNumber" size="20" maxlength="10" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Account Type</label>
					<select name="AccountType" id="AccountType">
						<option value="SavingsAccount">Savings Account</option>
						<option value="CheckingAccount">Checking Account</option>
					</select>
					<div class="clearfix"></div>
					<label>Check Type</label>
					<select name="CheckType" id="CheckType">
						<option value="Company">Company</option>
						<option value="Personal">Personal</option>
					</select>
					<div class="clearfix"></div>
					
					<label>Routing Number <span class="required">*</span></label>
					<input type="text" name="RoutingNumber" id="RoutingNumber" size="20" maxlength="9" autocomplete="Off"/>
					<div class="clearfix"></div>
					
					<label>Account Number <span class="required">*</span></label>
				  <input type="text" id="AccountNumber" name="AccountNumber" size="20" maxlength="17" autocomplete="Off"/>
					<div class="clearfix"></div>
					<label>Retype Account Number <span class="required">*</span></label>
					<input type="text" name="RetypeAccountNumber" id="RetypeAccountNumber" size="20" maxlength="17" autocomplete="Off"/>
					<div class="clearfix"></div>
				<?php }
					if(isset($_POST['payment_methods']) && $_POST['payment_methods'] != 'CreditCard' && $_POST['payment_methods'] != 'eCheck') {
					if($_POST['refnumlabel'] != "")
					{
					?>
						<h3><?php echo $_POST['refnumlabel']; ?> </h3>
						<input type="text"  id="clickandpledge_cp_ReferenceNumber" name="clickandpledge_cp_ReferenceNumber" placeholder="<?php echo $_POST['refnumlabel']?>" maxlength="50"/>
						<div class="clearfix"></div>
					<?php } ?>
				</div>
				</div>
<?php } ?>
