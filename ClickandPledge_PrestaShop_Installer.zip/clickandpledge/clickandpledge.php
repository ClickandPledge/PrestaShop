<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/


use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}
	// check if the order status is defined
		if (!defined('_PS_CNP_CREDITCARD_ORDER_STATUS_') || !defined('_PS_CNP_ECHECK_ORDER_STATUS_') || !defined('_PS_CNP_INVOICE_ORDER_STATUS_') || !defined('_PS_CNP_PURCHASE_ORDER_STATUS_') || !defined('_PS_CNP_CREDITCARD_RECURRING_ORDER_STATUS_') || !defined('_PS_CNP_ECHECK_RECURRING_ORDER_STATUS_')) {
				// order status is not defined - check if, it exists in the table
			$rq = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP Credit Card Payment"');
			
			if ($rq && isset($rq['id_order_state']) && intval($rq['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_CREDITCARD_ORDER_STATUS_', $rq['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_creditcard = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_creditcard) . ', 1, \'CnP Credit Card Payment\',\'payment\')');
				define('_PS_CNP_CREDITCARD_ORDER_STATUS_', $cnp_creditcard);

			   }

			$rq_check = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang` WHERE id_lang = 1 AND  name ="CnP eCheck Payment"');
			
			if ($rq_check && isset($rq_check['id_order_state']) && intval($rq_check['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_ECHECK_ORDER_STATUS_', $rq_check['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_echeck = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_echeck) . ', 1, \'CnP eCheck Payment\',\'payment\')');
				define('_PS_CNP_ECHECK_ORDER_STATUS_',$cnp_echeck);

			   }
			$rq_invoice = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP Awaiting Custom Payment"');
			
			if ($rq_invoice && isset($rq_invoice['id_order_state']) && intval($rq_invoice['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_INVOICE_ORDER_STATUS_', $rq_invoice['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'RoyalBlue\',1,1,\'clickandpledge\',1)');
				$cnp_invoice = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_invoice) . ', 1, \'CnP Awaiting Custom Payment\',\'cheque\')');
				define('_PS_CNP_INVOICE_ORDER_STATUS_', $cnp_invoice);

			   }
		
			   
			$rq_rp_credit = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP Credit Card Recurring Payment"');
			
			if ($rq_rp_credit && isset($rq_rp_credit['id_order_state']) && intval($rq_rp_credit['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_CREDITCARD_RECURRING_ORDER_STATUS_', $rq_rp_credit['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_creditcard_recurring = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_creditcard_recurring) . ', 1, \'CnP Credit Card Recurring Payment\',\'payment\')');
				define('_PS_CNP_CREDITCARD_RECURRING_ORDER_STATUS_', $cnp_creditcard_recurring);

			   }
			   
			$rq_rp_invoice = Db::getInstance()->getRow('SELECT `id_order_state` FROM `'._DB_PREFIX_.'order_state_lang`	WHERE id_lang = 1 AND  name ="CnP eCheck Recurring Payment"');
			
			if ($rq_rp_invoice && isset($rq_rp_invoice['id_order_state']) && intval($rq_rp_invoice['id_order_state']) > 0) {
				// order status exists in the table - define it.
				define('_PS_CNP_ECHECK_RECURRING_ORDER_STATUS_', $rq_rp_invoice['id_order_state']);

			} else {
		
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state` (`color`,`invoice`,`send_email`,`module_name`,`logable`) VALUES(\'LimeGreen\',1,1,\'clickandpledge\',1)');
				$cnp_echeck_recurring = Db::getInstance()->Insert_ID();
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'order_state_lang` (`id_order_state`, `id_lang`, `name`,`template`)
				VALUES(' . intval($cnp_echeck_recurring) . ', 1, \'CnP eCheck Recurring Payment\',\'payment\')');
				define('_PS_CNP_ECHECK_RECURRING_ORDER_STATUS_', $cnp_echeck_recurring);

			   }
			}
class clickandpledge extends PaymentModule
{
    private $_html = '';
    private $_postErrors = array();

    public $accountid;
    public $guid;
    public $extra_mail_vars;
	public $module_dir ="clickandpledge";
    public function __construct()
    {
        $this->name = 'clickandpledge';
        $this->tab = 'payments_gateways';
        $this->version = '4.0.0';
        $this->author = 'Click & Pledge';
        $this->controllers = array('validation');

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $config = Configuration::getMultiple(array('CLICKANDPLEDGE_LOGIN_ID', 'CLICKANDPLEDGE_KEY'));
        if (isset($config['CLICKANDPLEDGE_LOGIN_ID'])) {
            $this->accountid = $config['CLICKANDPLEDGE_LOGIN_ID'];
        }
        if (isset($config['CLICKANDPLEDGE_KEY'])) {
            $this->guid = $config['CLICKANDPLEDGE_KEY'];
        }
		 if (isset($config['clickandpledge_campaign'])) {
            $this->campaign = $config['clickandpledge_campaign'];
        }
		 if (isset($config['clickandpledge_transactionmode'])) {
            $this->transactionmode = $config['clickandpledge_transactionmode'];
        }
		if (isset($config['clickandpledge_status'])) {
            $this->status = $config['clickandpledge_status'];
        }
		 if (isset($config['clickandpledge_org_info'])) {
            $this->org_info = $config['clickandpledge_org_info'];
        }
		 if (isset($config['clickandpledge_terms_condition'])) {
            $this->terms_condition = $config['clickandpledge_terms_condition'];
        }
		 if (isset($config['clickandpledge_send_receipt'])) {
            $this->send_receipt = $config['clickandpledge_send_receipt'];
        }
		 if (isset($config['clickandpledge_hdncreditcard'])) {
            $this->creditcard = $config['clickandpledge_hdncreditcard'];
        }
		 if (isset($config['clickandpledge_hdnecheck'])) {
            $this->check = $config['clickandpledge_hdnecheck'];
        }
		 if (isset($config['options_clickandpledge_custompayment'])) {
            $this->custompayment = $config['options_clickandpledge_custompayment'];
        }
		 if (isset($config['clickandpledge_title'])) {
            $this->title = $config['clickandpledge_title'];
        }
		 if (isset($config['clickandpledge_refnumlabel'])) {
            $this->refnumlabel = $config['clickandpledge_refnumlabel'];
        }
		 if (isset($config['clickandpledge_payment_method_default'])) {
            $this->payment_method_default = $config['clickandpledge_payment_method_default'];
        }
		 
		if (isset($config['clickandpledge_recurring_contribution_'])) {
            $this->recurring = $config['clickandpledge_recurring_contribution_'];
        }
		if (isset($config['prdcty_clickandpledge_week'])) {
            $this->week = $config['prdcty_clickandpledge_week'];
        }
		if (isset($config['prdcty_clickandpledge_2_weeks'])) {
            $this->tweeks = $config['prdcty_clickandpledge_2_weeks'];
        }
		if (isset($config['prdcty_clickandpledge_month'])) {
            $this->month = $config['prdcty_clickandpledge_month'];
        }
		if (isset($config['prdcty_clickandpledge_2_months'])) {
            $this->tmonths = $config['prdcty_clickandpledge_2_months'];
        }
		if (isset($config['prdcty_clickandpledge_quarter'])) {
            $this->quarter = $config['prdcty_clickandpledge_quarter'];
        }
		if (isset($config['prdcty_clickandpledge_6_months'])) {
            $this->smonths = $config['prdcty_clickandpledge_6_months'];
        }
		if (isset($config['prdcty_clickandpledge_year'])) {
            $this->year = $config['prdcty_clickandpledge_year'];
        }
		if (isset($config['rec_clickandpledge_installment'])) {
            $this->installment = $config['rec_clickandpledge_installment'];
        }
		if (isset($config['rec_clickandpledge_subscription'])) {
            $this->subscription = $config['rec_clickandpledge_subscription'];
        }
		if (isset($config['clickandpledge_numberofpayments'])) {
            $this->numberofpayments = $config['clickandpledge_numberofpayments'];
        }
		if (isset($config['clickandpledge_dfltnoofpaymnts'])) {
            $this->dfltnoofpaymnts = $config['clickandpledge_dfltnoofpaymnts'];
        }
		if (isset($config['clickandpledge_maxrecurrings'])) {
            $this->maxrecurrings = $config['clickandpledge_maxrecurrings'];
        }
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Click & Pledge');
        $this->description = $this->trans('This module allows you to accept payments by Click & Pledge.');
        $this->confirmUninstall = $this->trans('Are you sure you want to delete these details?');
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
		
		if (!is_callable('curl_exec')){
				$this->warning = $this->trans("cURL extension must be enabled on your server to use this module.");
		}
        if ((!isset($this->accountid) || !isset($this->guid) || empty($this->accountid) || empty($this->guid))) {
            $this->warning = $this->trans('The "Account ID" and "GUID" fields must be configured before using this module.');
        }
        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->trans('No currency has been set for this module.');
        }

      
    }

    public function install()
    {
	 	
 	Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS ' . _DB_PREFIX_ . 'cnp_pscnpsettingsinfo (`cnpsettingsinfo_id` int(11) NOT NULL AUTO_INCREMENT,
			  `cnpsettingsinfo_clientid` varchar(255) NOT NULL,
			  `cnpsettingsinfo_clentsecret` varchar(255) NOT NULL,
			  `cnpsettingsinfo_granttype` varchar(255) NOT NULL,
			  `cnpsettingsinfo_scope` varchar(255) NOT NULL,
			   PRIMARY KEY (`cnpsettingsinfo_id`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8'); 
		Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS ' . _DB_PREFIX_ . 'cnp_pscnptokeninfo (`cnptokeninfo_id` int(11) NOT NULL AUTO_INCREMENT,
			`cnptokeninfo_username` varchar(255) NOT NULL,
			`cnptokeninfo_code` varchar(255) NOT NULL,
			`cnptokeninfo_accesstoken` text NOT NULL,
			`cnptokeninfo_refreshtoken` text NOT NULL,
			`cnptokeninfo_date_added` datetime NOT NULL,
			`cnptokeninfo_date_modified` datetime NOT NULL,
			 PRIMARY KEY (`cnptokeninfo_id`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8');
		Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS ' . _DB_PREFIX_ . 'cnp_pscnpaccountsinfo ( `cnpaccountsinfo_id` int(11) NOT NULL AUTO_INCREMENT,
			  `cnpaccountsinfo_orgid` varchar(100) NOT NULL,
  			  `cnpaccountsinfo_orgname` varchar(250) NOT NULL,
  	          `cnpaccountsinfo_accountguid` varchar(250) NOT NULL,
			  `cnpaccountsinfo_userfirstname` varchar(250) NOT NULL,
			  `cnpaccountsinfo_userlastname` varchar(250) NOT NULL,
			  `cnpaccountsinfo_userid` varchar(250) NOT NULL,
			  `cnpaccountsinfo_crtdon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  `cnpaccountsinfo_crtdby` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  PRIMARY KEY (`cnpaccountsinfo_id`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8');
		
		$cnppssql = Db::getInstance()->getRow('SELECT count(*) as cnt FROM `'._DB_PREFIX_.'cnp_pscnpsettingsinfo`');
			
			if ( $cnppssql['cnt'] == 0) {
				    $cnpfldname = 'connectwordpressplugin';
					$cnpfldtext = 'zh6zoyYXzsyK9fjVQGd8m+ap4o1qP2rs5w/CO2fZngqYjidqZ0Fhbhi1zc/SJ5zl';
					$cnpfldpwd = 'password';
					$cnpfldaccsid = 'openid profile offline_access';
				
			
				Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'cnp_pscnpsettingsinfo` (`cnpsettingsinfo_clientid`, `cnpsettingsinfo_clentsecret`, `cnpsettingsinfo_granttype`,`cnpsettingsinfo_scope`)
				VALUES("' . $cnpfldname . '","'.$cnpfldtext.'", "'.$cnpfldpwd.'","'.$cnpfldaccsid.'")');
			

			}
		
		
		 if (!parent::install() || !$this->registerHook('paymentOptions') || !$this->registerHook('paymentReturn') 
		 ||  !$this->registerHook('actionAdminControllerSetMedia')) {
            return false;
        }
        return true;
        /* return parent::install()
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn')
			&& $this->registerHook('orderConfirmation') 
			&& $this->registerHook('payment')
			&& Configuration::updateValue('CLICKANDPLEDGE_DEMO', 1) 
			&& Configuration::updateValue('CLICKANDPLEDGE_SEND_RECEIPT_US', '1') 
			&& Configuration::updateValue('CLICKANDPLEDGE_CREDITCARD', 'Credit Card') 
			&& Configuration::updateValue('PAYMENT_METHOD_DEFAULT', 'Creditcard')
        ;*/
    }

    public function uninstall()
    {
        return Configuration::deleteByName('CLICKANDPLEDGE_LOGIN_ID')
            && Configuration::deleteByName('CLICKANDPLEDGE_KEY')
			&& Configuration::deleteByName('clickandpledge_campaign')
			&& Configuration::deleteByName('clickandpledge_transactionmode')
			&& Configuration::deleteByName('clickandpledge_status')
			&& Configuration::deleteByName('clickandpledge_org_info')
			&& Configuration::deleteByName('clickandpledge_terms_condition')
			&& Configuration::deleteByName('clickandpledge_send_receipt')
			&& Configuration::deleteByName('options_clickandpledge_creditcard')
			&& Configuration::deleteByName('options_clickandpledge_check')
			&& Configuration::deleteByName('options_clickandpledge_custompayment')
			&& Configuration::deleteByName('clickandpledge_title')
			&& Configuration::deleteByName('clickandpledge_refnumlabel')
			&& Configuration::deleteByName('clickandpledge_payment_method_default')
			&& Configuration::deleteByName('clickandpledge_recurring_contribution_')
			&& Configuration::deleteByName('prdcty_clickandpledge_week')
			&& Configuration::deleteByName('prdcty_clickandpledge_2_weeks')
			&& Configuration::deleteByName('prdcty_clickandpledge_month')
			&& Configuration::deleteByName('prdcty_clickandpledge_2_months')
			&& Configuration::deleteByName('prdcty_clickandpledge_quarter')
			&& Configuration::deleteByName('prdcty_clickandpledge_6_months')
			&& Configuration::deleteByName('prdcty_clickandpledge_year')
			&& Configuration::deleteByName('rec_clickandpledge_installment')
			&& Configuration::deleteByName('rec_clickandpledge_subscription')
			&& Configuration::deleteByName('ind_clickandpledge_indefinite')
		
            && parent::uninstall()
        ;
    }
	public function floor_dec($number,$precision,$separator)
		{
		$numberpart=explode($separator,$number);
		$ceil_number= array($numberpart[0],substr($numberpart[1],0,2));
		return implode($separator,$ceil_number);
		}
	public function hookActionAdminControllerSetMedia()
		{
			
				if (method_exists($this->context->controller, 'addJquery'))
					$this->context->controller->addJquery();
	
				$this->context->controller->addJs($this->_path.'views/js/'.$this->name.'.js');
				$this->context->controller->addCSS($this->_path.'/views/css/custom.css');
			
		}
    private function _postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) { 
            if (!Tools::getValue('CLICKANDPLEDGE_LOGIN_ID')) {
                $this->_postErrors[] = $this->trans('The "Account Id" field is required.');
            } /*elseif (!Tools::getValue('clickandpledge_campaign')) {
                $this->_postErrors[] = $this->trans('The "Campaign" field is required.');
            }*/elseif (Tools::getValue('clickandpledge_transactionmode') == "") {
                $this->_postErrors[] = $this->trans('The "Transaction Mode" field is required.');
            }elseif (Tools::getValue('clickandpledge_status') == "") {
                $this->_postErrors[] = $this->trans('The "Status" field is required.');
				
            }/*elseif (!Tools::getValue('options_clickandpledge_creditcard') &&  
			         !Tools::getValue('options_clickandpledge_check') && 
					 !Tools::getValue('options_clickandpledge_custompayment')) {
                $this->_postErrors[] = $this->trans('The "Payment Methods" field is required.');
            }*/elseif (!Tools::getValue('clickandpledge_payment_method_default')) {
                $this->_postErrors[] = $this->trans('The "Default Payment Method" field is required.');
				
            }elseif (!Tools::getValue('rec_clickandpledge_onetimeonly') &&  
			         !Tools::getValue('rec_clickandpledge_recurring')) {
                $this->_postErrors[] = $this->trans('The "Payment Option" field is required.');
				
            }elseif (Tools::getValue('rec_clickandpledge_recurring') &&
					 !Tools::getValue('rec_clickandpledge_installment') &&  
			         !Tools::getValue('rec_clickandpledge_subscription')) {
                $this->_postErrors[] = $this->trans('The "Recurring Method" field is required.');
            }elseif (Tools::getValue('rec_clickandpledge_recurring') &&
			!Tools::getValue('prdcty_clickandpledge_week') &&  
			         !Tools::getValue('prdcty_clickandpledge_2_weeks') && 
					 !Tools::getValue('prdcty_clickandpledge_month')&& 
					 !Tools::getValue('prdcty_clickandpledge_2_months')&& 
					 !Tools::getValue('prdcty_clickandpledge_quarter')&& 
					 !Tools::getValue('prdcty_clickandpledge_6_months')&& 
					 !Tools::getValue('prdcty_clickandpledge_year')) {
                $this->_postErrors[] = $this->trans('The "Periodicity" field is required.');
            }/*elseif (Tools::getValue('rec_clickandpledge_installment') == "") {
                $this->_postErrors[] = $this->trans('The "Number of payments" field is required.');
				
            }
			elseif (Tools::getValue('rec_clickandpledge_installment') == "") {
                $this->_postErrors[] = $this->trans('The "Number of payments" field is required.');
				
            }
			elseif (Tools::getValue('clickandpledge_recurring_contribution_') &&
					!Tools::getValue('ind_clickandpledge_indefinite')) {
                $this->_postErrors[] = $this->trans('The "Enable Indefinite Recurring" field is required.');
            }*/
			
        }
    }

    private function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('CLICKANDPLEDGE_LOGIN_ID', Tools::getValue('CLICKANDPLEDGE_LOGIN_ID'));
			
           // Configuration::updateValue('CLICKANDPLEDGE_KEY', Tools::getValue('CLICKANDPLEDGE_KEY'));
			
			Configuration::updateValue('clickandpledge_campaign', Tools::getValue('clickandpledge_campaign'));
			
			Configuration::updateValue('clickandpledge_transactionmode', Tools::getValue('clickandpledge_transactionmode'));
			
			Configuration::updateValue('clickandpledge_status', Tools::getValue('clickandpledge_status'));
			
			Configuration::updateValue('clickandpledge_org_info', Tools::getValue('clickandpledge_org_info'));
			
			Configuration::updateValue('clickandpledge_terms_condition', Tools::getValue('clickandpledge_terms_condition'));
			
			Configuration::updateValue('clickandpledge_send_receipt', Tools::getValue('clickandpledge_send_receipt'));
			
			Configuration::updateValue('clickandpledge_hdnecheck', Tools::getValue('clickandpledge_hdnecheck'));
			
			Configuration::updateValue('clickandpledge_hdncreditcard', Tools::getValue('clickandpledge_hdncreditcard'));
			
			Configuration::updateValue('options_clickandpledge_custompayment', Tools::getValue('options_clickandpledge_custompayment'));
			
			Configuration::updateValue('clickandpledge_title', Tools::getValue('clickandpledge_title'));
			
			Configuration::updateValue('clickandpledge_refnumlabel', Tools::getValue('clickandpledge_refnumlabel'));
			
			Configuration::updateValue('clickandpledge_payment_method_default', Tools::getValue('clickandpledge_payment_method_default'));
			
			Configuration::updateValue('rec_clickandpledge_onetimeonly', Tools::getValue('rec_clickandpledge_onetimeonly'));
			
			Configuration::updateValue('rec_clickandpledge_recurring', Tools::getValue('rec_clickandpledge_recurring'));
			
			Configuration::updateValue('clickandpledge_payment_option_default', Tools::getValue('clickandpledge_payment_option_default'));
			
			Configuration::updateValue('prdcty_clickandpledge_week', Tools::getValue('prdcty_clickandpledge_week'));
			
			Configuration::updateValue('prdcty_clickandpledge_2_weeks', Tools::getValue('prdcty_clickandpledge_2_weeks'));
			
			Configuration::updateValue('prdcty_clickandpledge_month', Tools::getValue('prdcty_clickandpledge_month'));
			
			Configuration::updateValue('prdcty_clickandpledge_2_months', Tools::getValue('prdcty_clickandpledge_2_months'));
			
			Configuration::updateValue('prdcty_clickandpledge_quarter', Tools::getValue('prdcty_clickandpledge_quarter'));
			
			Configuration::updateValue('prdcty_clickandpledge_6_months', Tools::getValue('prdcty_clickandpledge_6_months'));
			
			Configuration::updateValue('prdcty_clickandpledge_year', Tools::getValue('prdcty_clickandpledge_year'));
			
			Configuration::updateValue('rec_clickandpledge_installment', Tools::getValue('rec_clickandpledge_installment'));
			
			Configuration::updateValue('rec_clickandpledge_subscription', Tools::getValue('rec_clickandpledge_subscription'));
			
			Configuration::updateValue('clickandpledge_recurringtype_default', Tools::getValue('clickandpledge_recurringtype_default'));
			
			Configuration::updateValue('clickandpledge_numberofpayments', Tools::getValue('clickandpledge_numberofpayments'));
			Configuration::updateValue('clickandpledge_dfltnoofpaymnts', Tools::getValue('clickandpledge_dfltnoofpaymnts'));
			Configuration::updateValue('clickandpledge_maxrecurrings', Tools::getValue('clickandpledge_maxrecurrings'));
        }
        $this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Notifications.Success'));
    }

    private function _displayCheck()
    {
        return $this->display(__FILE__, './views/templates/hook/infos.tpl');
    }

    public function getContent()
    {
        $this->_html = '';
		//Tools::addJS('');
		
        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        }
 //$this->_html .=$this->displayMybuttonLink();
        $this->_html .= $this->_displayCheck();
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    public function hookPaymentOptions($params)
    {
	
        if (!$this->active) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
		
		$payment_options = [
         
            $this->getclickandpledgePaymentOption($params),
       
        ];
        return $payment_options;
		
      
    }
	public function getclickandpledgePaymentOption($params)
    {
        $clicknpledgeOption = new PaymentOption();
        $clicknpledgeOption->setCallToActionText($this->trans('Click and Pledge'))
                       ->setForm($this->generateclicknpledgeForm($params))
                       ->setAdditionalInformation($this->display(__FILE__, 'views/templates/front/clickandpledge_infos.tpl'));
                   
        return $clicknpledgeOption;
    }
    protected function generateclicknpledgeForm($params)
    { 

		
     global $cookie, $smarty;
		
		$currencies_module = $this->getCurrency((int)$params['cart']->id_currency);
		$currency = $this->checkCurrency($params['cart']);
		$iso_code_num = $currencies_module->iso_code; 
		//&& Configuration::get('CLICKANDPLEDGE_KEY') != ''
		if(Configuration::get('clickandpledge_status') && Configuration::get('CLICKANDPLEDGE_LOGIN_ID') != '' )
		{ 
		    $displaystatus = true;
			$login_id =  Configuration::get('CLICKANDPLEDGE_LOGIN_ID');
			$login_key = $this->getpsCnPAccountGUID($login_id);
			$app_campaign = Configuration::get('clickandpledge_campaign');
			$mode = Configuration::get('clickandpledge_transactionmode') == 1 ? 'Production' : 'Test';
			
		}
		else{
		    $displaystatus = false;
		}
			
			$org_info        =  Configuration::get('clickandpledge_org_info');
			$terms_condition = Configuration::get('clickandpledge_terms_condition');
			$send_recepit    = Configuration::get('clickandpledge_send_receipt') == 1 ? 'yes' : 'no';
			$defalut_payment = Configuration::get('clickandpledge_payment_method_default');
			$recurring       = Configuration::get('rec_clickandpledge_recurring')== 'on' ? 'yes' : 'no';
			$onetimeonly     = Configuration::get('rec_clickandpledge_onetimeonly')== 'on' ? 'yes' : 'no';
		
			$defalutpaymentoption = Configuration::get('clickandpledge_payment_option_default');
		
			$week =  Configuration::get('prdcty_clickandpledge_week');
			$week2 =  Configuration::get('prdcty_clickandpledge_2_weeks');
			$month =  Configuration::get('prdcty_clickandpledge_month');
			$months2 =  Configuration::get('prdcty_clickandpledge_2_months');
			$quarter =  Configuration::get('prdcty_clickandpledge_quarter');
			$months6 =  Configuration::get('prdcty_clickandpledge_6_months');
			$year =  Configuration::get('prdcty_clickandpledge_year');
		
			$recurring_installment = Configuration::get('rec_clickandpledge_installment');
			$recurring_subscription = Configuration::get('rec_clickandpledge_subscription');
			$dfltrecurringsubscription = Configuration::get('clickandpledge_recurringtype_default');
		
			$numberofpayments = Configuration::get('clickandpledge_numberofpayments');
			$dfltnumberofpayments = Configuration::get('clickandpledge_dfltnoofpaymnts');
			$maxnumberofpayments = Configuration::get('clickandpledge_maxrecurrings');
			
			$refnumlabel = Configuration::get('clickandpledge_refnumlabel');
			$titles      = Configuration::get('clickandpledge_title');
			
			
			 $creditcard = $defalut_payment == 'Creditcard' ? 'Credit Card' : Configuration::get('clickandpledge_hdncreditcard');
			 $check = $defalut_payment == 'eCheck' ? 'eCheck' : Configuration::get('clickandpledge_hdnecheck');
	
			$custompayment = $defalut_payment == 'custompayment' ? 'custompayment' : Configuration::get('options_clickandpledge_custompayment');
		
			if($creditcard == "on"){$creditcard ="Credit Card";}
			if($check == "on"){$check ="eCheck";}
		    if($custompayment == "on"){$custompayment ="custompayment";}
			  
			if($recurring_installment == "on"){$recurring_installment ="Installment";}
			if($recurring_subscription == "on"){$recurring_subscription ="Subscription";}
			if($subscription_indefinite == "on"){$subscription_indefinite ="indefinite";}
		/*	
			if($recurring_installment == "on"){$recurring_installment ="Installment";}
			if($recurring_subscription == "on"){$recurring_subscription ="Subscription";}
			if($subscription_indefinite == "on"){$subscription_indefinite ="indefinite";}*/
			
			if($week == "on"){$week ="Week";}
			if($week2 == "on"){$week2 ="2 Weeks";}
			if($month == "on"){$month ="Month";}
			if($months2 == "on"){$months2 ="2 Months";}
			if($quarter == "on"){$quarter ="Quarter";}
			if($months6 == "on"){$months6 ="6 Months";}
			if($year == "on"){$year ="Year";}
			
			
			 //shipping address
		    $invoiceAddress = new Address((int)$params['cart']->id_address_delivery);
			
			//billing address
		    $billingAddress = new Address((int)$params['cart']->id_address_invoice);
			$customer = new Customer((int)$cookie->id_customer);
			$shipping_method = new Carrier((int)$params['cart']->id_carrier);
	
			$oldMessage = new Message();
			
			$getmesdetails =$oldMessage->getMessageByCartId((int)$params['cart']->id);
			//MessageCore::getMessageByCartId(intval($params['cart']->id));
			
			 $shipping_method_name = $shipping_method->name;
			 $Totaltax = (float)Tools::ps_round(($params['cart']->getOrderTotal(true, Cart::BOTH) - $params['cart']->getOrderTotal(false, Cart::BOTH)),2);
		
			$productamount = $params['cart']->getOrderTotal(false, Cart::BOTH);
		 	$finalamount = $params['cart']->getOrderTotal(true, Cart::BOTH);		
		//echo $params['cart']->getOrderTotal(false);
			$cnpParams = array();
			$cnpParams['x_login'] = $login_id;
			$cnpParams['x_tran_key'] = $login_key;
			$cnpParams['x_org_info'] = $org_info;
			$cnpParams['x_app_campaign'] = $app_campaign; 
			$cnpParams['x_send_recepit'] = $send_recepit;
			$cnpParams['x_terms_condition'] = $terms_condition;
			$cnpParams['x_thankyou_message'] = $thankyou_message;
			$cnpParams['x_titles'] = $titles;
			$cnpParams['x_referenceno'] = $refnumlabel;
			//$cnpParams['x_currency'] = $cookie->id_currency;
			$cnpParams['x_currency_code'] = $iso_code_num;
			
			$cnpParams['x_version'] = '4.0';
			$cnpParams['x_delim_data'] = 'TRUE';
			$cnpParams['x_delim_char'] = '|';
			$cnpParams['x_relay_response'] = 'FALSE';
			$cnpParams['x_type'] = 'AUTH_CAPTURE';
			//$cnpParams['x_method'] = 'CC';
			$cnpParams['x_test_request'] = $mode;
			$cnpParams['x_invoice_num'] = (int)$params['cart']->id;
			$cnpParams['x_amount'] = number_format($params['cart']->getOrderTotal(true, 3), 2, '.', '');
			$cnpParams['x_address1'] = $invoiceAddress->address1;
			$cnpParams['x_address2'] = $invoiceAddress->address2;
			$cnpParams['x_zip'] = $invoiceAddress->postcode;
			$cnpParams['customer_gender'] = $customer->id_gender;
			$cnpParams['x_first_name'] = $customer->firstname;
			$cnpParams['x_last_name'] = $customer->lastname;
			$cnpParams['x_email'] = $customer->email;
			$cnpParams['customer_birthday'] = $customer->birthday;
			$cnpParams['x_gift'] = $params['cart']->gift;
			$cnpParams['x_gift_message'] = "";	
			$cnpParams['x_comment_message'] = $getmesdetails['message'];				
			$cnpParams['x_phone'] = (!empty($invoiceAddress->phone_mobile)) ? $invoiceAddress->phone_mobile : $invoiceAddress->phone;
			$cnpParams['x_city'] = $invoiceAddress->city;
			$cnpParams['x_state'] = State::getNameById($invoiceAddress->id_state);
			$cnpParams['x_country'] = $invoiceAddress->id_country;
			$cnpParams['x_total_product'] = $params['cart']->nbProducts();
			
			if($cnpParams['x_state']==""){
			$cnpParams['x_state']="States Not Available";
			
			}
			if($cnpParams['x_gift']==1){			
				$cnpParams['x_gift_message'] = $params['cart']->gift_message;
			}else{
				$cnpParams['x_gift_message'] = "Not selected";
			}
			
			// billing information
			$cnpParams['x_b_address1'] = $billingAddress->address1;
			$cnpParams['x_b_address2'] = $billingAddress->address2;
			$cnpParams['x_b_zip'] = $billingAddress->postcode;
			$cnpParams['x_b_first_name'] = $billingAddress->firstname;
			$cnpParams['x_b_last_name'] = $billingAddress->lastname;
			$cnpParams['x_b_company'] = $billingAddress->company;
			$cnpParams['x_b_add_info'] = $billingAddress->other;
			$cnpParams['x_b_phone_home'] = $billingAddress->phone;
			$cnpParams['x_b_phone'] = (!empty($billingAddress->phone_mobile)) ? $billingAddress->phone_mobile : $billingAddress->phone;
			$cnpParams['x_b_city'] = $billingAddress->city;
			$cnpParams['x_b_state'] = State::getNameById($billingAddress->id_state);
			$cnpParams['x_b_country'] = $billingAddress->id_country;
			$cnpParams['x_shipping_method'] = $shipping_method_name;
			if($cnpParams['x_b_state']==""){
			$cnpParams['x_b_state']="States Not Available";
			
			}
			
			//shipping contact information
			$cnpParams['x_s_first_name'] = $invoiceAddress->firstname;
			$cnpParams['x_s_last_name'] = $invoiceAddress->lastname;
			$cnpParams['x_s_company'] = $invoiceAddress->company;
			$cnpParams['x_s_add_info'] = $invoiceAddress->other;
			$cnpParams['x_s_phone_home'] = $invoiceAddress->phone;
			$cnpParams['x_s_phone'] = (!empty($invoiceAddress->phone_mobile)) ? $invoiceAddress->phone_mobile : $invoiceAddress->phone;
		
			$val=$params['cart']->getProducts();
	//echo "<pre>";//print_r($val);
		
			$applyAllRules = new SpecificPrice();
			//print_r($SpecificPrice);
		    $currency = Currency::getCurrency((int)$params['cart']->id_currency);
			$sign = $currency['sign'];
		
			$taxCalculationMethod = Group::getPriceDisplayMethod((int)$customer->id_default_group);
	
		if($taxCalculationMethod == PS_TAX_EXC){$useTax = 0;}else{$useTax = 1;}
		
		//= ($taxCalculationMethod == PS_TAX_EXC) ? false : true;
			
			 $shipping=Tools::displayPrice($params['cart']->getOrderTotal($useTax, Cart::ONLY_SHIPPING), $currency);
			$shipping_tax = "000";
			$cr=array($sign,",","-");
		
			if($taxCalculationMethod == PS_TAX_EXC)
			{
			    $shipping_cost = $params['cart']->getOrderTotal($useTax, Cart::ONLY_SHIPPING);
			}
			else
			{
			   $shipping_cost = $params['cart']->getOrderTotal('', Cart::ONLY_SHIPPING);
			}
		
			 $shipping_tax = (float)($params['cart']->getOrderTotal(1, Cart::ONLY_SHIPPING) - $params['cart']->getOrderTotal(0, Cart::ONLY_SHIPPING));
	
			$cnpParams['x_shipping_cost']  = $shipping_cost;
			$cnpParams['x_shipping_tax']   = $shipping_tax;
		
			if($shipping_tax !=0)
			{
				 $Totaltax = Tools::ps_round(($Totaltax - $shipping_tax),2);
			}
			 
			$discount = $params['cart']->getCartRules();
		
			$coupon_code = '';$shipping_free = '';
			$coupon_discount = 000;
			if(!empty($discount))
			{
				
				for($i=0;$i < count($discount);$i++)
				{
				 $coupon_code .= $discount[$i]['code'].',';
				 $shipping_free .= $discount[$i]['free_shipping'].',';
				 
				  $coupon_discount = number_format(str_replace($cr,'',$discount[$i]['value_real']),'2','.','') + $coupon_discount;
				 }
			}
			$freeship_arr = explode(",",$shipping_free);
			if (in_array(1, $freeship_arr))
			{
			$cnpParams['x_shipping_cost']  = 0.00;
			$cnpParams['x_shipping_tax']   = 0.00;
			}
			$cnpParams['x_coupon_code'] = substr($coupon_code,0,-1);
			$cnpParams['x_coupon_discount'] = $coupon_discount;
			$cnpParams['x_total_tax'] = $Totaltax;
			$cnpParams['x_final_amount'] = $finalamount;
			for($m=0;$m<count($val);$m++)
			{
			 $subtotal_amount +=  Tools::ps_round(Tools::ps_round($val[$m]['price_with_reduction_without_tax'],2) + $val[$m]['price_attribute'],2) * $val[$m]['cart_quantity'];
			}
			
			$cnpParams['x_subtotal_amount'] = $subtotal_amount;
			for($i=0;$i<count($val);$i++)
			{
				$myprod = new Product($val[$i]['id_product']);
				
				$features = $myprod->getFrontFeatures($val[$i]['id_product']);
					
				$getFeature = new Feature();
				$ff = $getFeature->getFeature(1,6);
				
				$pid = $val[$i]['id_product'];
				
				 if(count($features) > 0)
				 {
				 foreach($features as $new_few)
				 {
				 $fid =  $new_few['id_feature'];
			
				 
		$rq = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'feature_product` WHERE id_feature ='.$fid.' AND  id_product ='.$pid.'');
		if(count($rq) > 0)
		{
		$new_fid = $rq['id_feature'];
		$new_fid_val = $rq['id_feature_value'];
		$feacture_name = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'feature_lang` WHERE id_feature ='.$new_fid.' AND  name in("SKU","Campaign") and id_lang =1');
		if(count($feacture_name) > 0)
		{
		$feacture_value = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'feature_value_lang` WHERE id_feature_value ='.$new_fid_val.' and id_lang =1');
			if($feacture_name['name'] == 'SKU')
			{
			$cnpParams['x_product_sku['.$i.']'] = $feacture_value['value'];
			}
			if($feacture_name['name'] == 'Campaign')
			{
			$cnpParams['x_product_campaign['.$i.']'] = $feacture_value['value'];
			 }
		}	
		}
				
				}
				
				}
				
				
				$nn = $applyAllRules->getSpecificPrice($val[$i]['id_product'],$params['cart']->id_shop,$cookie->id_currency,$cookie->id_country,0,1,null,0,0,1);
				//print_r($nn);
				/*if(is_array($nn))
				{
					if($nn['reduction_type'] == 'percentage')
						{
				//$cnpParams['x_product_price['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2);
			//	$cnpParams['x_product_price_unitdiscount['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2) * $nn['reduction'];
					$cnpParams['x_product_price_unitdiscount['.$i.']'] = Tools::ps_round(Tools::ps_round($val[$i]['price_with_reduction'],2) + $val[$i]['price_attribute'],2) * $nn['reduction'];		          
						//echo "wait".$cal_pro;
						}else{
				//$cnpParams['x_product_price['.$i.']'] = Tools::ps_round($myprod->price + $val[$i]['price_attribute'],2);
				$cnpParams['x_product_price_unitdiscount['.$i.']'] = Tools::ps_round(Tools::ps_round($val[$i]['price_with_reduction'],2) + $val[$i]['price_attribute'],2) - $nn['reduction'];
						}
				}*/
		//	exit;
			
				 $cnpParams['x_product_price['.$i.']'] = Tools::ps_round($val[$i]['price_with_reduction_without_tax'],2);
				
				// need to work   + $val[$i]['price_attribute'],2
			     $cnpParams['x_product_id['.$i.']'] = $val[$i]['id_product'];
				 $cnpParams['x_product_unique_id['.$i.']'] = $val[$i]['unique_id'];
			     $cnpParams['x_product_name['.$i.']'] = $val[$i]['name'];
				 $cnpParams['x_product_quantity['.$i.']'] = $val[$i]['cart_quantity'];
						
				if($coupon_discount == "000")
				{ 
				   /*$unittax = ((($val[$i]['price_with_reduction_without_tax'] - $val[$i]['ecotax']) ) * $val[$i]['rate'])/100 ;* $val[$i]['cart_quantity'])*/
					$unittax =  ($val[$i]['total_wt'] - $val[$i]['total'])   ;
				    $cnpParams['x_product_tax['.$i.']'] = Tools::ps_round($unittax ,'2');
				    $totalunittax += Tools::ps_round($unittax ,'2');
				}
				else
				{
					$getDiscount = $params['cart']->getCartRules();//echo $getDiscount[$i]['code'];
				//print_r($getDiscount);
				    $unitdiscount = 0;
					if(!empty($getDiscount))
					{ 
						
						for($k=0;$k < count($getDiscount);$k++)
						{
						  if($getDiscount[$k]['code'] != "")
						   {
						
							
						   if($getDiscount[$k]['reduction_percent'] != "0.00")
						   {
						   //echo $getDiscount[$k]['reduction_percent']."**";* $val[$i]['quantity']
						     $unitdiscount += ((Tools::ps_round($val[$i]['price_with_reduction_without_tax'],2) * $getDiscount[$k]['reduction_percent'] ) / 100) ;
							 $taxdiscnt = (($val[$i]['total_wt'] - $val[$i]['total']) * $getDiscount[$k]['reduction_percent'] ) / 100;
							 $unittax = ($val[$i]['total_wt'] - $val[$i]['total'])- $taxdiscnt;
						   }
						   else if($getDiscount[$k]['reduction_amount'] != "0.00")
						   { 
							  if($getDiscount[$k]['product_restriction'] == 1 && $getDiscount[$k]['reduction_product'] == $val[$i]['id_product'] )
							  {
								  $unitdiscount +=  $getDiscount[$k]['value_tax_exc'] ;
								   $taxdiscnt = (Tools::ps_round((($val[$i]['total_wt'] - $val[$i]['total'])/$val[$i]['total_wt'])*100));
								  $unittax =  (Tools::ps_round((($val[$i]['total']-$unitdiscount) * $taxdiscnt) / 100,2));
							  }
							   else if($getDiscount[$k]['product_restriction'] == 0 && $getDiscount[$k]['carrier_restriction'] == 0 && $getDiscount[$k]['group_restriction'] == 0 && $getDiscount[$k]['cart_rule_restriction'] == 0 ){
								   $unitdiscount +=   ((Tools::ps_round($val[$i]['price_with_reduction_without_tax'],2) / $subtotal_amount) * $getDiscount[$k]['value_tax_exc']) * $val[$i]['quantity']; 
								   $taxdiscnt = (($val[$i]['total_wt'] - $val[$i]['total'])-$unitdiscount);
								   $unittax = ($val[$i]['total_wt'] - $val[$i]['total'])- $taxdiscnt;
							   }
							  elseif($getDiscount[$k]['product_restriction'] == 1 && $getDiscount[$k]['reduction_product'] != $val[$i]['id_product'] )
							  {
								  $unittax = ($val[$i]['total_wt'] - $val[$i]['total']);
							  }
						      
						   }
						  
						}else{
							
						    $cnpParams['x_product_price_unitdiscount['.$i.']'] = 0;
						}
						$cnpParams['x_product_price_unitdiscount['.$i.']'] = Tools::ps_round($unitdiscount*$val[$i]['cart_quantity'],2);
						}
						
					}
				
					/*$unittax = ((($val[$i]['price_with_reduction_without_tax'] - $val[$i]['ecotax']) - $unitdiscount) * $val[$i]['rate'])/100 ;
					$unittaxca=(Tools::ps_round($val[$i]['price_with_reduction'],2)-Tools::ps_round($unitdiscount,2))*$val[$i]['cart_quantity'];*/
					
					 //$unittax = ($val[$i]['total_wt'] - $val[$i]['total'])- $taxdiscnt;
				    $cnpParams['x_product_tax['.$i.']'] = Tools::ps_round($unittax ,'2');
					$totalunittax += Tools::ps_round(($unittax ) ,'2');
				}
				
				 $cnpParams['x_selected_attribute_price['.$i.']'] = $val[$i]['price_attribute'];
				 $cnpParams['x_product_attributes_name['.$i.']'] = $val[$i]['attributes'];
				 
			}
		//	echo $Totaltax."<br>".$totalunittax."<br>".Tools::ps_round(($Totaltax - $totalunittax),2);
			$cnpParams['x_difference_tax'] = Tools::ps_round(($Totaltax - $totalunittax),2);
		
			$isFailed = Tools::getValue('aimerror');

			$cards = array();
			$recurring_units = array();
			$recurring_method = array();
			if($creditcard != '')$cards['Creditcard'] = $creditcard;
			if($check != '')$cards['eCheck'] = $check;
			if($titles != '' &&  Configuration::get('options_clickandpledge_custompayment') == "on")
			{
			 $CustomPayments = explode(';', html_entity_decode($titles ));
				if(count($CustomPayments) > 0) {
					foreach($CustomPayments as $key => $val) {
						if(trim($val) != '') {
							$cards[trim($val)] = trim($val);
						
						}
					}
				}		
			}
		
			if($recurring == 'yes')
			{
			if($week != '')$recurring_units['Week'] = $week;
			if($week2 != '')$recurring_units['Weeks2'] = $week2;
			if($month != '')$recurring_units['Month'] = $month;
			if($months2 != '')$recurring_units['Months2'] = $months2;
			if($quarter != '')$recurring_units['Quarter'] = $quarter;
			if($months6 != '')$recurring_units['Months6'] = $months6;
			if($year != '')$recurring_units['Year'] = $year;
			
			if($recurring_installment != '')$recurring_method['installment'] = $recurring_installment;
			if($recurring_subscription != '')
				{
				
				$recurring_method['subscription'] = $recurring_subscription;
				if($subscription_indefinite != '') $indefinite = $subscription_indefinite;
				
				}
			}
			$numberofpayments=Configuration::get('clickandpledge_numberofpayments');
			$this->context->smarty->assign('p', $cnpParams);			
			$this->context->smarty->assign('cards', $cards);
			$this->context->smarty->assign('recurring', $recurring);
			$this->context->smarty->assign('onetimeonly', $onetimeonly);
			$this->context->smarty->assign('transactionmode', $mode);
			$this->context->smarty->assign('recurring_units', $recurring_units);
			$this->context->smarty->assign('recurring_method', $recurring_method);
			$this->context->smarty->assign('indefinite', $indefinite);
			$this->context->smarty->assign('numberofpayments', $numberofpayments);
			$this->context->smarty->assign('dfltnumberofpayments', $dfltnumberofpayments);
			$this->context->smarty->assign('maxnumberofpayments', $maxnumberofpayments);
		    $this->context->smarty->assign('defalutpaymentoption', $defalutpaymentoption);
			$this->context->smarty->assign('dfltrecurringsubscription', $dfltrecurringsubscription);
			$this->context->smarty->assign('isFailed', $isFailed);
			$this->context->smarty->assign('defalut_payment', $defalut_payment);
			$this->context->smarty->assign('refnumlabel', $refnumlabel);
			$this->context->smarty->assign('module_dir', $base_dir.'modules/clickandpledge/');
			$this->context->smarty->assign('cartfinalamount',$finalamount);
			
			
		 if($displaystatus)
			{
			   
			    return $this->context->smarty->fetch('module:clickandpledge/views/templates/front/clickandpledge_form.tpl');
			   //return $this->display(__FILE__, 'views/templates/front/clickandpledge_form.tpl');
			}

        
    }
    public function hookPaymentReturn($params)
    {
       
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency((int)($cart->id_currency));
        $currencies_module = $this->getCurrency((int)$cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function renderForm()
    {
		
				 $recoptions = array(
				  array(
					'id_option' => 1,       
					'name' => '(Supported for Credit card and eCheck)'    
				  ),
				
				);
				$prdctyoptions = array(
				  array(
					'id_option1' => "clickandpledge_week",      
					'name' => 'Week'    
				  ),
				  array(
					'id_option1' => "clickandpledge_2_weeks",
					'name' => '2 Weeks'
				  ),
				   array(
					'id_option1' => "clickandpledge_month",
					'name' => 'Month'
				  ),
				  array(
					'id_option1' => "clickandpledge_2_months",      
					'name' => '2 Months'    
				  ),
				  array(
					'id_option1' => "clickandpledge_quarter",
					'name' => 'Quarter'
				  ),
				   array(
					'id_option1' => "clickandpledge_6_months",
					'name' => '6 Months'
				  ),
					   array(
					'id_option1' => "clickandpledge_year",
					'name' => 'Year'
				  ),
			
				);
		$recpayoptions = array(
			  array(
				'id_payoption' => "clickandpledge_onetimeonly",      
				'payname' => 'One Time Only'   
			  ),
			 array(
				'id_payoption' => "clickandpledge_recurring",      
				'payname' => 'Recurring'    
			  ),
			
			);
			 $rectypptions = array(
			  array(
				'id_option3' => "clickandpledge_installment",      
				'name' => 'Installment (example: Split $1000 into 10 payments of $100 each)'   
			  ),
			 array(
				'id_option3' => "clickandpledge_subscription",      
				'name' => 'Subscription (example: Pay $10 every month for 20 times)'    
			  ),
			
			);
			$indrecoptions = array(
			  array(
				'id_option4' => "clickandpledge_indefinite",      
				'name' => ' Indefinite (~) optional'    
			  ),
			
			);
		$cnppssql = Db::getInstance()->getRow('SELECT count(*) as cnt FROM `'._DB_PREFIX_.'cnp_pscnpaccountsinfo`');
		$cnpacntcnt = $cnppssql['cnt'];
		if($cnpacntcnt == 0) {$cnpdsplylgnd = "Login";}else{$cnpdsplylgnd = "Change User";}
		$fields_form_customization = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans($cnpdsplylgnd),
                    'icon' => 'icon-cogs'
                ),
               'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Connect User Name'),
                        'name' => 'clickandpledge_connectusername',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Code'),
                        'name' => 'clickandpledge_connectcode',
                        'desc'    => $this->l('Choose Payment Methods.'), 
                    ),
				   
                ),
                'submit' => array(
                    'title' => $this->trans('Get the Code'),
                )
            ),
        );
	$cnpaccquery = "SELECT * FROM `"._DB_PREFIX_."cnp_pscnpaccountsinfo`";
$cnpaccntslsts = Db::getInstance()->executeS($cnpaccquery);
	
	//getAccounts
		$rtrnacnts ="";$cnpaacountsoptions =array();
	   foreach ($cnpaccntslsts as $cnpaccntslst) {
		   $cnporgid = $cnpaccntslst['cnpaccountsinfo_orgid'];
		   $cnporgname = $cnpaccntslst['cnpaccountsinfo_orgid']." [". $cnpaccntslst['cnpaccountsinfo_orgname'] ."]" ;
		   $rtrnacnts =  array(
					'aid_option' => $cnporgid,      
					'aname' => $cnporgname);
		  $cnpaacountsoption = array_push($cnpaacountsoptions,$rtrnacnts);
		   
		   if($cnporgid == Configuration::get('CLICKANDPLEDGE_LOGIN_ID')){
				 $found = true;
				 $cnporgid = Configuration::get('CLICKANDPLEDGE_LOGIN_ID');
			}
	   }
		/*echo $cnplogin_id =  Configuration::get('CLICKANDPLEDGE_LOGIN_ID');
		if($cnplogin_id == "")
		{
			$cnporgid =$cnporgid;
			
		}else{$cnporgid = $cnplogin_id;}*/
		if(!isset($found)) {$cnporgid = $cnpaccntslsts[0]['cnpaccountsinfo_orgid'];}
		//getCampaigns
	$rtrncampns ="";$cnpcampaignoptions =array();
	$cnpcnctcamp = $this->getpsCnPConnectCampaigns($cnporgid);
	 for($inc = 0 ; $inc < count($cnpcnctcamp);$inc++)
	   {
		
		   $cnpcalias = $cnpcnctcamp[$inc]->alias;
		   $cnpcaliasname = $cnpcnctcamp[$inc]->name." (".$cnpcnctcamp[$inc]->alias.")";
		   $rtrncampns =  array(
					'cid_option' => $cnpcalias,      
					'cname' => $cnpcaliasname);

		  $cnpcampaignoption = array_push($cnpcampaignoptions,$rtrncampns);
      }
		$options = array(); $cnpdfltmthdoptions = array();$hdncheck="";$hdncrdcrd="";
		$cnpactivepaymentslst = $this->getpsCnPactivePaymentList($cnporgid);
		
		    $responsearramex              =  $cnpactivepaymentslst->GetAccountDetailResult->Amex;
			$responsearrJcb               =  $cnpactivepaymentslst->GetAccountDetailResult->Jcb;
			$responsearrMaster            =  $cnpactivepaymentslst->GetAccountDetailResult->Master;
			$responsearrVisa              =  $cnpactivepaymentslst->GetAccountDetailResult->Visa;
			$responsearrDiscover          =  $cnpactivepaymentslst->GetAccountDetailResult->Discover;
			$responsearrecheck            =  $cnpactivepaymentslst->GetAccountDetailResult->Ach;
			$responsearrCustomPaymentType =  $cnpactivepaymentslst->GetAccountDetailResult->CustomPaymentType;
			if(($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true) )
			{
				if($responsearrVisa == true){$cnpaccptcrds="Visa";}
				if($responsearrJcb == true){$cnpaccptcrds.=",Jcb";}
				if($responsearrMaster == true){$cnpaccptcrds.=",MasterCard";}
				if($responsearramex == true){$cnpaccptcrds.=",Amex";}
				if($responsearrDiscover == true){$cnpaccptcrds.=",Discover";}
				 $pname = 'Credit Card ('.$cnpaccptcrds.')';
		   	 $rtrnpymnts = array(
					'id_option' => "clickandpledge_creditcard",       
					'name' => $pname,);
		     $cnppaymntoption = array_push($options,$rtrnpymnts);
			$hdncrdcrd ="Creditcard";
			 $rtrndpymnts = array(
					'id_lpa_prov' => "Creditcard",       
					'name' => "Credit Card",);
		     $cnpdfltmthdoption = array_push($cnpdfltmthdoptions,$rtrndpymnts);
			 }
		if($responsearrecheck == true){
			 $rtrnpymnts = array(
					'id_option' => "clickandpledge_check",
					'name' => 'eCheck'
				  );
					$hdncheck ="eCheck";
				$cnppaymntoption = array_push($options,$rtrnpymnts); 
			$rtrndpymnts = array(
					'id_lpa_prov' => "eCheck",       
					'name' => "eCheck",);
		     $cnpdfltmthdoption = array_push($cnpdfltmthdoptions,$rtrndpymnts);
		}
		if($responsearrCustomPaymentType == true){
			  $rtrnpymnts =array(
					'id_option' => "clickandpledge_custompayment",
					'name' => 'Custom Payment'
				  );
			$cnppaymntoption = array_push($options,$rtrnpymnts);
		}
		$cnpcnctcamp = $this->getpsCnPConnectUsername($cnporgid);
		$settingvar ="Settings  [ You are logged in as : ".$cnpcnctcamp." ]";
		$fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans($settingvar),
                    'icon' => 'icon-cogs'
                ),
				
                'input' => array(
					 array(
                        'type' => 'radio',
                        'label' => $this->l('Click & Pledge Status'),
                        'name' => 'clickandpledge_status',
                        'values' => array(
                            array(
                                'id' => 'clickandpledge_status',
                                'value' => '1',
								'checked' => 'checked',
                                'label' => $this->l('Enable')
                            ),
                            array(
                                'id' => 'clickandpledge_status',
                                'value' => '0',
                                'label' => $this->l('Disable')
                            )
                        )
						
                    ),
					 array(
                        'type' => 'radio',
                        'label' => $this->l('Transaction mode'),
                        'name' => 'clickandpledge_transactionmode',
                        'values' => array(
                            array(
                                'id' => 'clickandpledge_transactionmode',
                                'value' => '1',
								'checked' => 'checked',
                                'label' => $this->l('Production')
                            ),
                            array(
                                'id' => 'clickandpledge_transactionmode',
                                'value' => '0',
								
                                'label' => $this->l('Test')
                            )
                        )
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->trans('Account Id'),
                        'name' => 'CLICKANDPLEDGE_LOGIN_ID',
                       	 'options' => array(
                            'query' => $cnpaacountsoptions,
                            'id' => 'aid_option',
                            'name' => 'aname'
                        )
						
                    ),
                   
					  array(
                        'type' => 'select',
                        'label' => $this->trans('Connect Campaign URL Alias'),
                        'name' => 'clickandpledge_campaign',
                       	   'options' => array(
                            'query' => $cnpcampaignoptions,
                            'id' => 'cid_option',
                            'name' => 'cname'
                        )
                    ),
					
					array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Payment Methods'),         
						 
						  'name'    => 'options',
						  'class'=>'clspaymntmthd',
						                
						  'values'  => array(
							'query' => $options,                     
							'id'    => 'id_option',                 
							'name'  => 'name')
                ),
				 array(
                        'type' => 'textarea',
                        'label' => $this->trans('Title(s)'),
                        'name' => 'clickandpledge_title',
                        
                    ),  array(
                        'type' => 'text',
                        'label' => $this->trans('Reference Number Label'),
                        'name' => 'clickandpledge_refnumlabel',
					
                       
                    ),
				  array(
                        'col' => 3,
                        'type' => 'select',
                        'prefix' => '<i class="icon icon-tag"></i>',
                        'name' => 'clickandpledge_payment_method_default',
                        'label'=> $this->l('Default Payment Method'),
					
					    'options' => array(
                            'query' => $cnpdfltmthdoption,
                            'id' => 'id_lpa_prov',
                            'name' => 'name'
                        )
                        
                    ),
					array(
                        'type' => 'switch',
                        'label' => $this->trans('Send Receipt to Patron'),
                        'name' => 'clickandpledge_send_receipt',
                        
						'values' => array(
                            array(
                                'id' => 'clickandpledge_send_receipt',
                                'value' => '1',
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'id' => 'clickandpledge_send_receipt',
                                'value' => '0',
                                'label' => $this->l('No')
                            )
                        )
                    ),
					
					 array(
                        'type' => 'textarea',
                        'label' => $this->trans('Receipt Header'),
                        'name' => 'clickandpledge_org_info',
                       
                    ),  array(
                        'type' => 'textarea',
                        'label' => $this->trans('Terms & Condition'),
                        'name' => 'clickandpledge_terms_condition',
                        
                    ),
					 array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Payment options'),         
						  'name'    => 'rec',
						  'class'    => "clsrecmthd",  						 
						  'values'  => array( 
							'query' => $recpayoptions,                     
							'id'    => 'id_payoption',                 
							'name'  => 'payname')
              		  	),
					 array(
                        'col' => 3,
                        'type' => 'select',
                        'prefix' => '<i class="icon icon-tag"></i>',
                        'name' => 'clickandpledge_payment_option_default',
                        'label'=> $this->l('Default Payment Option'),
						'class'=> 'clsdfltpayoptn',
						 'options' => array(
                            'query' => array(
                               
                                array(
                                    'id_dpopa_prov' => 'Recurring',
                                    'name' => $this->l('Recurring')
                                ),
                                array(
                                    'id_dpopa_prov' => 'One Time Only',
                                    'name' => $this->l('One Time Only')
                                ),
                               
                            ),
                            'id' => 'id_dpopa_prov',
                            'name' => 'name'
                        )
                        
                    ),
					array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Recurring Types'),         
						  'name'    => 'rec',
						  'class'    => "clsrecmthd",  
						                 
						  'values'  => array( 
							'query' => $rectypptions,                     
							'id'    => 'id_option3',                 
							'name'  => 'name')
              		  	),
					array(
                        'col' => 3,
                        'type' => 'select',
                        'prefix' => '<i class="icon icon-tag"></i>',
                        'name' => 'clickandpledge_recurringtype_default',
                        'label'=> $this->l('Default Recurring Type'),
						'class'=> 'clsdfltrectyp',
						'options' => array(
                            'query' => array(
                               
                                array(
                                    'id_drtpa_prov' => 'Subscription',
                                    'name' => $this->l('Subscription')
                                ),
                                array(
                                    'id_drtpa_prov' => 'Installment',
                                    'name' => $this->l('Installment')
                                ),
                               
                            ),
                            'id' => 'id_drtpa_prov',
                            'name' => 'name'
                        )
                        
                    ),
					array(
						  'type'    => 'checkbox',                   
						  'label'   => $this->l('Periodicity'),         
						  'name'    => 'prdcty',
						  'class'    => "clsprdcty",  
						       
						  'values'  => array( 
							'query' => $prdctyoptions,                     
							'id'    => 'id_option1',                 
							'name'  => 'name')
              		  	),
					 array(
                        'type' => 'radio',
                        'label' => $this->l('Number of payments'),
                        'name' => 'clickandpledge_numberofpayments',
						  'class'    => "clsnoofpaymnts", 
                        'values' => array(
                            array(
                                'id' => 'clickandpledge_numberofpayments',
                                'value' => 'indefinite',
								'checked' => 'checked',
                                'label' => $this->l('Indefinite Only')
                            ),
                            array(
                                'id' => 'clickandpledge_numberofpayments',
                                'value' => 'openfield',
                                'label' => $this->l('Open Field Only')
                            ),
							array(
                                'id' => 'clickandpledge_numberofpayments',
                                'value' => 'indefiniteopen',
                                'label' => $this->l('Indefinite + Open Field Option')
                            ),
							array(
                                'id' => 'clickandpledge_numberofpayments',
                                'value' => 'fixednumber',
                                'label' => $this->l(' Fixed Number - No Change Allowed')
                            )
                        )
						
                    ),	
					array(
                        'type' => 'text',
                        'label' => $this->trans('Default number of payments'),
                        'name' => 'clickandpledge_dfltnoofpaymnts',
                         'class'    => "clsdfltnoofpaymnts", 
						'maxlength' => "3",
                    ),
					array(
                        'type' => 'text',
                        'label' => $this->trans('Maximum number of instalments allowed'),
                        'name' => 'clickandpledge_maxrecurrings',
                         'class'    => "clsmaxnoofpaymnts", 
						'maxlength' => "3",
                    ),
					
						array(
                        'type' => 'hidden',
                        'name' => 'clickandpledge_hdndfltpaymnt',
                        'required' => true
                    ),
				
					array(
                        'type' => 'hidden',
                       	'value' => $hdncrdcrd,
                        'name' => 'clickandpledge_hdncreditcard',
						'required' => true
                        
                    ),
						
					array(
                        'type' => 'hidden',
                       	'value' => $hdncheck,
                        'name' => 'clickandpledge_hdnecheck',
						'required' => true
                        
                    ),
                ),
                'submit' => array(
                    'title' => $this->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
		
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
        );

        $this->fields_form = array();
		
		if ( $cnpacntcnt == 0) {return $helper->generateForm(array($fields_form_customization));}
		else{ return $helper->generateForm(array($fields_form_customization,$fields_form ));}
    }
	public function getpsCnPAccountGUID($accid)
		{
		
			$cnpAccountGUId ="";
			$cnppssql = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'cnp_pscnpaccountsinfo` where cnpaccountsinfo_orgid ="'.$accid.'"');
			$cnpAccountGUId      = $cnppssql['cnpaccountsinfo_accountguid'];
			return $cnpAccountGUId;
		
		}
		public function getpsCnPConnectUsername($accid)
		{
		
			$cnpAccountusername ="";
			$cnppssql = Db::getInstance()->getRow('SELECT cnpaccountsinfo_userid FROM `'._DB_PREFIX_.'cnp_pscnpaccountsinfo` where cnpaccountsinfo_orgid ="'.$accid.'"');
			$cnpAccountusername      = $cnppssql['cnpaccountsinfo_userid'];
			return $cnpAccountusername;
		
		}
	public function getpsCnPConnectCampaigns($cnpaccid)
	{

		$cnpacountid = $cnpaccid;
	    $cnpaccountGUID = $this->getpsCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr  = new SimpleXMLElement("<GetActiveCampaignList2></GetActiveCampaignList2>");
			$cnpsel ="";
			$xmlr->addChild('accountId', $cnpacountid);
			$xmlr->addChild('AccountGUID', $cnpaccountGUID);
			$xmlr->addChild('username', $cnpUID);
			$xmlr->addChild('password', $cnpKey);
			$response = $client->GetActiveCampaignList2($xmlr); 
			$responsearr =  $response->GetActiveCampaignList2Result->connectCampaign;
		}
		
		return $responsearr;
			
	}
	public function getpsCnPactivePaymentList($cnpaccid)
	{

		$cmpacntacptdcards = "";
		$cnpacountid = $cnpaccid;
		$cnpaccountGUID = $this->getpsCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect1  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client1   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect1);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr1  = new SimpleXMLElement("<GetAccountDetail></GetAccountDetail>");
			$xmlr1->addChild('accountId',$cnpacountid);
			$xmlr1->addChild('accountGUID',$cnpaccountGUID);
			$xmlr1->addChild('username',$cnpUID);
			$xmlr1->addChild('password',$cnpKey);
			$response1                    =  $client1->GetAccountDetail($xmlr1);
			
			
		}
		
		return $response1;
	
	}
    public function getConfigFieldsValues()
    {
        return array(
			'clickandpledge_transactionmode' => Tools::getValue('clickandpledge_transactionmode', Configuration::get('clickandpledge_transactionmode')),			
			'clickandpledge_status' => Tools::getValue('clickandpledge_status', Configuration::get('clickandpledge_status')),			
            'CLICKANDPLEDGE_LOGIN_ID' => Tools::getValue('CLICKANDPLEDGE_LOGIN_ID', Configuration::get('CLICKANDPLEDGE_LOGIN_ID')),			
            'clickandpledge_campaign' => Tools::getValue('clickandpledge_campaign', Configuration::get('clickandpledge_campaign')),		
				'options_clickandpledge_creditcard' => Tools::getValue('options_clickandpledge_creditcard', Configuration::get('options_clickandpledge_creditcard')),			
			'options_clickandpledge_check' => Tools::getValue('options_clickandpledge_check', Configuration::get('options_clickandpledge_check')),	
			'options_clickandpledge_custompayment' => Tools::getValue('options_clickandpledge_custompayment', Configuration::get('options_clickandpledge_custompayment')),			
			'clickandpledge_title' => Tools::getValue('clickandpledge_title', Configuration::get('clickandpledge_title')),			
			'clickandpledge_refnumlabel' => Tools::getValue('clickandpledge_refnumlabel', Configuration::get('clickandpledge_refnumlabel')),			
			'clickandpledge_payment_method_default' => Tools::getValue('clickandpledge_payment_method_default', Configuration::get('clickandpledge_payment_method_default')),			
			'clickandpledge_send_receipt' => Tools::getValue('clickandpledge_send_receipt', Configuration::get('clickandpledge_send_receipt')),			
			'clickandpledge_org_info' => Tools::getValue('clickandpledge_org_info', Configuration::get('clickandpledge_org_info')),			
			'clickandpledge_terms_condition' => Tools::getValue('clickandpledge_terms_condition', Configuration::get('clickandpledge_terms_condition')),			
				
			'rec_clickandpledge_onetimeonly' => Tools::getValue('rec_clickandpledge_onetimeonly', Configuration::get('rec_clickandpledge_onetimeonly')),			
			'rec_clickandpledge_recurring' => Tools::getValue('rec_clickandpledge_recurring', Configuration::get('rec_clickandpledge_recurring')),			
			'clickandpledge_payment_option_default' => Tools::getValue('clickandpledge_payment_option_default', Configuration::get('clickandpledge_payment_option_default')),			
			'rec_clickandpledge_installment' => Tools::getValue('rec_clickandpledge_installment', Configuration::get('rec_clickandpledge_installment')),			
			'rec_clickandpledge_subscription' => Tools::getValue('rec_clickandpledge_subscription', Configuration::get('rec_clickandpledge_subscription')),			
			'clickandpledge_recurringtype_default' => Tools::getValue('clickandpledge_recurringtype_default', Configuration::get('clickandpledge_recurringtype_default')),			
			'prdcty_clickandpledge_week' => Tools::getValue('prdcty_clickandpledge_week', Configuration::get('prdcty_clickandpledge_week')),
			'prdcty_clickandpledge_2_weeks' => Tools::getValue('prdcty_clickandpledge_2_weeks', Configuration::get('prdcty_clickandpledge_2_weeks')),
			'prdcty_clickandpledge_month' => Tools::getValue('prdcty_clickandpledge_month', Configuration::get('prdcty_clickandpledge_month')),
			'prdcty_clickandpledge_2_months' => Tools::getValue('prdcty_clickandpledge_2_months', Configuration::get('prdcty_clickandpledge_2_months')),
			'prdcty_clickandpledge_quarter' => Tools::getValue('prdcty_clickandpledge_quarter', Configuration::get('prdcty_clickandpledge_quarter')),
			'prdcty_clickandpledge_6_months' => Tools::getValue('prdcty_clickandpledge_6_months', Configuration::get('prdcty_clickandpledge_6_months')),
			'prdcty_clickandpledge_year' => Tools::getValue('prdcty_clickandpledge_year', Configuration::get('prdcty_clickandpledge_year')),			
			'clickandpledge_numberofpayments' => Tools::getValue('clickandpledge_numberofpayments', Configuration::get('clickandpledge_numberofpayments')),			
			'clickandpledge_dfltnoofpaymnts' => Tools::getValue('clickandpledge_dfltnoofpaymnts', Configuration::get('clickandpledge_dfltnoofpaymnts')),			
			'clickandpledge_maxrecurrings' => Tools::getValue('clickandpledge_maxrecurrings', Configuration::get('clickandpledge_maxrecurrings')),			
			'clickandpledge_hdndfltpaymnt' => Tools::getValue('clickandpledge_payment_method_default', Configuration::get('clickandpledge_payment_method_default')),
			
			'clickandpledge_hdncreditcard' => Tools::getValue('clickandpledge_hdncreditcard', Configuration::get('clickandpledge_hdncreditcard')),
			'clickandpledge_hdnecheck' => Tools::getValue('clickandpledge_hdnecheck', Configuration::get('clickandpledge_hdnecheck')),
        );
    }

    
}