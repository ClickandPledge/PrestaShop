function check_is_recurring(res,name_file)
{
if(res == true)
{
var xmlhttp;
document.getElementById("myDiv").innerHTML= "<img src='../modules/clickandpledge/loading.gif' width='16px' height='16px'>";
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET",name_file+"?action=recurring",true);
xmlhttp.send();
}else{
document.getElementById("myDiv").innerHTML= "";
}
}
function block_recurring(res)
{
	if(res == true)
	document.getElementById("myDiv").style.display="block";
	else
	document.getElementById("myDiv").style.display="none";
}
function block_subscription(res)
{
	if(res == true)
	document.getElementById("myDiv1").style.display="block";
	else
	document.getElementById("myDiv1").style.display="none";
}
function block_creditcard(res)
{
	if(res == true)
	{
	document.getElementById("myDiv3").style.display="block";
	}
	else
	{
	if(document.getElementById("clickandpledge_check").checked == false)
	document.getElementById("myDiv3").style.display="none";
	}
}
function block_echek(res)
{
	if(res == true)
	document.getElementById("myDiv3").style.display="block";
	else
	if(document.getElementById("clickandpledge_creditcard").checked == false)
	document.getElementById("myDiv3").style.display="none";
}
function check_idefinite(mess)
{
if(mess == "Subscription")
document.getElementById("indefinite_id").innerHTML= '<div style="margin-bottom:10px;"><input type="checkbox" name="indefinite_times" value="999" onclick="is_validating(this.checked)" id="indefinite_times">&nbsp;<label class="option" for="indefinite_times"><span></span>Indefinite Recurring</lable></div>';
else
document.getElementById("indefinite_id").innerHTML= '';
is_validating(false);
}
/*function recurring_setup(payopttyp)
{
	
  if(payopttyp == 1)
		{
			document.getElementById("dvrecurtyp").style.display = "block";
			document.getElementById("dvprdcty").style.display = "block";
			document.getElementById("dvnoofpaymnts").style.display = "block";
		}
	else if(payopttyp == 0){
		document.getElementById("dvrecurtyp").style.display = "none";
		document.getElementById("dvprdcty").style.display = "none";
		document.getElementById("dvnoofpaymnts").style.display = "none";
	
}
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
//document.getElementById("dvrecurtyp").style.display="block";
}
function is_validating(mess)
{
if(mess)
{
	document.getElementById("times").style.display = 'none';
	document.getElementById("enable").style.display = 'inline';
}
else
{
	document.getElementById("times").style.display = 'inline';
	document.getElementById("enable").style.display = 'none';
}
}*/
