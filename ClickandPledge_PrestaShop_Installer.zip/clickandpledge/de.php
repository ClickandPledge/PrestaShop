<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{clickandpledge}prestashop>clickandpledge_f745351b1387473d3d2de5bfe18d3562'] = 'Fehler, bitte Kreditkarteninformationen überprüfen';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_1814fc250eea61e13aa95e81b61bf72a'] = 'Bezahlen Sie mit clickandpledge';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_442155d68aea78b4ef707796d76ca48c'] = 'Visa-Logo';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_f65943f43529e119969e533dc6f691f9'] = 'MasterCard-Logo';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_2937b5dab08029b1055b37c98a98d740'] = 'Discover-Logo';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_3b8a6fa58a71e7448c264c9dc61e6904'] = 'American Express Logo';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_1edaf23879c3b52a8df80069d2af3cef'] = 'Sichere Kreditkartenzahlung mit Authorize.net';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_f11b368cddfe37c47af9b9d91c6ba4f0'] = 'Vollständiger Name';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_a44217022190f5734b2f72ba1e4f8a79'] = 'Kartennummer';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_8c1279db4db86553e4b9682f78cf500e'] = 'Verfallsdatum';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_60a104dc50579d60cbc90158fada1dcf'] = 'CVV';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_6149e52c36edb9ee4494d5412e42eef2'] = 'die letzten drei Ziffern auf der Rückseite Ihrer Kreditkarte';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_40566b26dcc126bce704f2c1d622a6a3'] = 'Bestellung bestätigen';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_9286982d71addb45ad3a9472282f2c69'] = 'Ihre Kartennummer ist falsch';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_cb313e911b15b21b57f4fc7b53058e4f'] = 'Zahlung mit Authorize.net erhalten ';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_6a26f548831e6a8c26bfbbd9f6ec61e0'] = 'Hilfe';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_11a4b229c0e206b831f729572618553f'] = 'In Ihrem PrestaShop Admin-Panel';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_bc6781f2b59d4e973bd0075baab62a40'] = 'Füllen Sie das Login-ID-Feld mit der von Authorize.net vorgesehenen Kennung aus';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_95eb440b753d6505aad5c3f72b50eec9'] = 'Füllen Sie das Schlüsselfeld mit dem Transaktionsschlüssel von Authorize.net aus';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_f3ef34226d51e9ca88eaa2f20d7ffb91'] = 'Login-ID';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_897356954c2cd3d41b221e3f24f99bba'] = 'Schlüssel';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_1ee1c44c2dc81681f961235604247b81'] = 'Modus:';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_756d97bb256b8580d4d71ee0c547804e'] = 'Produktion';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_0cbc6611f5540bd0809a388dc95a615b'] = 'Test';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_291cdb0a8abb42484f5d44dc20540ce6'] = 'Karten:';
$_MODULE['<{clickandpledge}prestashop>clickandpledge_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aktualisierungseinstellungen';
$_MODULE['<{clickandpledge}prestashop>hookorderconfirmation_2e2117b7c81aa9ea6931641ea2c6499f'] = 'Ihre Bestellung vom';
$_MODULE['<{clickandpledge}prestashop>hookorderconfirmation_75fbf512d744977d62599cc3f0ae2bb4'] = ' ist abgeschlossen.';
$_MODULE['<{clickandpledge}prestashop>hookorderconfirmation_30163d8fc3068e8297e7ab5bf32aec87'] = 'Ihre Bestellung wird so schnell wie möglich zugeschickt.';
$_MODULE['<{clickandpledge}prestashop>hookorderconfirmation_0db71da7150c27142eef9d22b843b4a9'] = 'Bei Fragen oder für weitere Informationen, kontaktieren Sie bitte unseren';
$_MODULE['<{clickandpledge}prestashop>hookorderconfirmation_64430ad2835be8ad60c59e7d44e4b0b1'] = 'Kunden-Support';
$_MODULE['<{clickandpledge}prestashop>hookorderconfirmation_8de637e24570c1edb0357826a2ad5aea'] = 'Wir haben ein Problem bei Ihrer Bestellung festgestellt. Wenn Sie denken, dies sei ein Fehler, können Sie an unseren';

?>