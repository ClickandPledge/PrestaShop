$(document).ready(function(){
 $(".clickandpledge_recurring_contribution_").click(function(){

              
                        toggleFields();
                    });
           

                function toggleFields() {
                    if ($('#delivery_option_0_0').is(':checked')) {
                        $('#address1').show();
                        $('#postcode').show();
                        $('#city').show();
                        $('#id_state').hide();
                    } else {
                        $('#address1').hide();
                        $('#postcode').hide();
                        $('#city').hide();
                        $('#id_state').show();
                    }
                }
});
